import java.util.Properties
// Inject secrets from local.properties into BuildConfig (non-committed file)
val localProps = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) file.inputStream().use { load(it) }
}
val facebookToken = (localProps.getProperty("FACEBOOK_ACCESS_TOKEN") ?: "")
val eventbriteToken = (localProps.getProperty("EVENTBRITE_PRIVATE_TOKEN") ?: "")
val ticketmasterApiKey = (localProps.getProperty("TICKETMASTER_API_KEY") ?: "")
val meetupApiKey = (localProps.getProperty("MEETUP_API_KEY") ?: "")
val bandsintownAppId = (localProps.getProperty("BANDSINTOWN_APP_ID") ?: "")
val googleSearchApiKey = (localProps.getProperty("GOOGLE_SEARCH_API_KEY") ?: "")
val googleSearchCx = (localProps.getProperty("GOOGLE_SEARCH_CX") ?: "")
val authBaseUrl = (localProps.getProperty("AUTH_BASE_URL") ?: "")
val trustedOrganizerIds = (localProps.getProperty("TRUSTED_EVENTBRITE_ORGANIZER_IDS") ?: "")
val trustedOrganizerNames = (localProps.getProperty("TRUSTED_EVENTBRITE_ORGANIZER_NAMES") ?: "")
val forcedEventbriteUrls = (localProps.getProperty("FORCED_EVENTBRITE_URLS") ?: "")
val targetFacebookGroupUrls = (localProps.getProperty("TARGET_FACEBOOK_GROUP_URLS") ?: "")
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
    id("com.google.gms.google-services")
}

android {
    namespace = "com.weakglow.linken"
    compileSdk {
        version = release(36)
    }

    defaultConfig {
        applicationId = "com.weakglow.linken"
        minSdk = 25
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        manifestPlaceholders["GOOGLE_MAPS_API_KEY"] = (localProps.getProperty("GOOGLE_MAPS_API_KEY") ?: "")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            // no-op
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.compose.animation)
    implementation(libs.androidx.navigation.compose)
    
    // Room
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    
    // WorkManager
    implementation(libs.androidx.work.runtime.ktx)
    
    // Networking
    implementation(libs.retrofit)
    implementation(libs.retrofit.gson)
    implementation(libs.okhttp)
    implementation(libs.gson)
    implementation("io.coil-kt:coil-compose:2.6.0")
    
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)

    // Google Maps Compose
    implementation("com.google.maps.android:maps-compose:2.11.4")
    implementation("com.google.android.gms:play-services-maps:18.2.0")

    // Firebase Auth
    implementation(platform("com.google.firebase:firebase-bom:33.4.0"))
    implementation("com.google.firebase:firebase-auth-ktx")
}

android.buildTypes.forEach { bt ->
    bt.buildConfigField("String", "FACEBOOK_ACCESS_TOKEN", "\"$facebookToken\"")
    bt.buildConfigField("String", "EVENTBRITE_PRIVATE_TOKEN", "\"$eventbriteToken\"")
    bt.buildConfigField("String", "TICKETMASTER_API_KEY", "\"$ticketmasterApiKey\"")
    bt.buildConfigField("String", "MEETUP_API_KEY", "\"$meetupApiKey\"")
    bt.buildConfigField("String", "BANDSINTOWN_APP_ID", "\"$bandsintownAppId\"")
    bt.buildConfigField("String", "GOOGLE_SEARCH_API_KEY", "\"$googleSearchApiKey\"")
    bt.buildConfigField("String", "GOOGLE_SEARCH_CX", "\"$googleSearchCx\"")
    bt.buildConfigField("String", "TRUSTED_EVENTBRITE_ORGANIZER_IDS", "\"$trustedOrganizerIds\"")
    bt.buildConfigField("String", "TRUSTED_EVENTBRITE_ORGANIZER_NAMES", "\"$trustedOrganizerNames\"")
    bt.buildConfigField("String", "FORCED_EVENTBRITE_URLS", "\"$forcedEventbriteUrls\"")
    bt.buildConfigField("String", "TARGET_FACEBOOK_GROUP_URLS", "\"$targetFacebookGroupUrls\"")
    bt.buildConfigField("String", "AUTH_BASE_URL", "\"$authBaseUrl\"")
}
