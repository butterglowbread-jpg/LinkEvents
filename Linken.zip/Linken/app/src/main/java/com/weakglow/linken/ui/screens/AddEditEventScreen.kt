﻿package com.weakglow.linken.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.weakglow.linken.data.Event
import com.weakglow.linken.ui.viewmodel.EventViewModel
import java.util.*
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.android.gms.maps.model.LatLng
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.google.android.gms.maps.model.CameraPosition
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import android.location.Geocoder
import java.util.Locale
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import coil.compose.SubcomposeAsyncImage
import androidx.compose.ui.layout.ContentScale
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditEventScreen(
    navController: NavController,
    viewModel: EventViewModel,
    eventId: Long?
) {
    val isEditing = eventId != null
    var event by remember { mutableStateOf<Event?>(null) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedDate by remember { mutableStateOf(Calendar.getInstance()) }
    var selectedTime by remember { mutableStateOf(Calendar.getInstance()) }
    var category by remember { mutableStateOf("General") }
    var selectedColor by remember { mutableStateOf(0xFF9C27B0L) }
    var location by remember { mutableStateOf("") }
    var latitude by remember { mutableStateOf<Double?>(null) }
    var longitude by remember { mutableStateOf<Double?>(null) }
    var showMapDialog by remember { mutableStateOf(false) }
    var selectedHour by remember { mutableStateOf(selectedTime.get(Calendar.HOUR_OF_DAY)) }
    var selectedMinute by remember { mutableStateOf(0) }
    val categories = listOf("General", "Work", "Personal", "Health", "Social", "Other")
    var bannerImagePath by remember { mutableStateOf<String?>(null) }

    val preferredDate by viewModel.preferredCreationDateMs.collectAsState(initial = null)

    val colorOptions = listOf(
        0xFF9C27B0L, 0xFF7B1FA2L, 0xFF6A1B9AL, 0xFFAB47BCL,
        0xFF6200EEL, 0xFF3700B3L, 0xFF03DAC6L, 0xFF4ECDC4L
    )

    LaunchedEffect(eventId) {
        if (eventId != null) {
            val loadedEvent = viewModel.getEventById(eventId)
            if (loadedEvent != null) {
                event = loadedEvent
                title = loadedEvent.title
                description = loadedEvent.description
                selectedDate = Calendar.getInstance().apply {
                    timeInMillis = loadedEvent.dateTime
                }
                selectedTime = Calendar.getInstance().apply {
                    timeInMillis = loadedEvent.dateTime
                }
                category = loadedEvent.category
                selectedColor = loadedEvent.color
                location = loadedEvent.location ?: ""
                latitude = loadedEvent.latitude
                longitude = loadedEvent.longitude
                bannerImagePath = loadedEvent.imageUrl
            }
        } else if (preferredDate != null) {
            selectedDate = Calendar.getInstance().apply { timeInMillis = preferredDate!! }
            selectedHour = 12
            selectedMinute = 0
        }
    }

    val combinedDateTime = remember(selectedDate, selectedHour, selectedMinute) {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.YEAR, selectedDate.get(Calendar.YEAR))
            set(Calendar.MONTH, selectedDate.get(Calendar.MONTH))
            set(Calendar.DAY_OF_MONTH, selectedDate.get(Calendar.DAY_OF_MONTH))
            set(Calendar.HOUR_OF_DAY, selectedHour)
            set(Calendar.MINUTE, selectedMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        calendar.timeInMillis
    }

    val context = LocalContext.current
    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val dir = java.io.File(context.cacheDir, "banners")
                if (!dir.exists()) dir.mkdirs()
                val name = "picked_${System.currentTimeMillis()}.jpg"
                val file = java.io.File(dir, name)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    java.io.FileOutputStream(file).use { output ->
                        input.copyTo(output)
                    }
                }
                bannerImagePath = "file://${file.absolutePath}"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Edit Event" else "New Event") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(
                        onClick = {
                            if (title.isNotBlank()) {
                                if (combinedDateTime < System.currentTimeMillis() - 60000L) {
                                    return@TextButton
                                }
                                val newEvent = if (isEditing && event != null) {
                                    event!!.copy(
                                        title = title,
                                        description = description,
                                        dateTime = combinedDateTime,
                                        category = category,
                                        color = selectedColor,
                                        location = location.takeIf { it.isNotBlank() },
                                        latitude = latitude,
                                        longitude = longitude,
                                        imageUrl = bannerImagePath ?: event!!.imageUrl
                                    )
                                } else {
                                    Event(
                                        title = title,
                                        description = description,
                                        dateTime = combinedDateTime,
                                        category = category,
                                        color = selectedColor,
                                        location = location.takeIf { it.isNotBlank() },
                                        latitude = latitude,
                                        longitude = longitude,
                                        imageUrl = bannerImagePath
                                    )
                                }

                                if (isEditing) {
                                    viewModel.updateEvent(newEvent)
                                } else {
                                    viewModel.insertEvent(newEvent)
                                }
                                navController.popBackStack()
                            }
                        }
                    ) {
                        Text("Save")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (combinedDateTime < System.currentTimeMillis() - 60000L) {
                Text(
                    text = "Event date must be in the future",
                    color = MaterialTheme.colorScheme.error
                )
            }
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = title.isBlank()
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 100.dp),
                maxLines = 5
            )

            Text(text = "Banner Image", style = MaterialTheme.typography.labelLarge)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = { pickImageLauncher.launch("image/jpeg") }) {
                    Text(if (bannerImagePath != null) "Change JPEG" else "Pick JPEG")
                }
            }
            if (bannerImagePath != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    SubcomposeAsyncImage(
                        model = bannerImagePath,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Location") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("e.g., Vilnius Old Town") },
                enabled = false
            )
            Button(onClick = { showMapDialog = true }, modifier = Modifier.fillMaxWidth()) {
                Text(if (latitude != null && longitude != null) "Change Location on Map" else "Pick Location on Map")
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Date",
                        style = MaterialTheme.typography.labelLarge
                    )
                    DatePicker(
                        selectedDate = selectedDate,
                        onDateSelected = { selectedDate = it }
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Time",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Time:", modifier = Modifier.padding(end = 8.dp))
                        var hourDropdownExpanded by remember { mutableStateOf(false) }
                        var minuteDropdownExpanded by remember { mutableStateOf(false) }
                        var selectedHour by remember { mutableStateOf(selectedTime.get(Calendar.HOUR_OF_DAY)) }
                        var selectedMinute by remember { mutableStateOf(0) }
                        Box {
                            Button(onClick = { hourDropdownExpanded = true }) {
                                Text(selectedHour.toString().padStart(2, '0'))
                            }
                            DropdownMenu(
                                expanded = hourDropdownExpanded,
                                onDismissRequest = { hourDropdownExpanded = false }
                            ) {
                                (0..23).forEach { hour ->
                                    DropdownMenuItem(
                                        text = { Text(hour.toString().padStart(2, '0')) },
                                        onClick = {
                                            selectedHour = hour
                                            hourDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Box {
                            Button(onClick = { minuteDropdownExpanded = true }) {
                                Text(selectedMinute.toString().padStart(2, '0'))
                            }
                            DropdownMenu(
                                expanded = minuteDropdownExpanded,
                                onDismissRequest = { minuteDropdownExpanded = false }
                            ) {
                                (0..50 step 10).forEach { minute ->
                                    DropdownMenuItem(
                                        text = { Text(minute.toString().padStart(2, '0')) },
                                        onClick = {
                                            selectedMinute = minute
                                            minuteDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Text(
                text = "Category",
                style = MaterialTheme.typography.labelLarge
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = category == cat,
                        onClick = { category = cat },
                        label = { Text(cat) }
                    )
                }
            }

            Text(
                text = "Color",
                style = MaterialTheme.typography.labelLarge
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                colorOptions.forEach { color ->
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(color))
                            .then(
                                if (selectedColor == color) {
                                    Modifier.border(3.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(24.dp))
                                } else {
                                    Modifier
                                }
                            )
                            .clickable { selectedColor = color }
                    )
                }
            }
        }

        if (showMapDialog) {
            AlertDialog(
                onDismissRequest = { showMapDialog = false },
                confirmButton = {
                    TextButton(onClick = { showMapDialog = false }) {
                        Text("Done")
                    }
                },
                title = { Text("Select Event Location") },
                text = {
                    var markerPosition by remember { mutableStateOf<LatLng?>(if (latitude != null && longitude != null) LatLng(latitude!!, longitude!!) else null) }
                    val vilniusCenter = LatLng(54.6872, 25.2797)
                    val cameraPositionState = rememberCameraPositionState {
                        position = if (markerPosition != null)
                            CameraPosition(markerPosition!!, 16f, 0f, 0f)
                        else
                            CameraPosition(vilniusCenter, 16f, 0f, 0f)
                    }
                    val context = LocalContext.current
                    val scope = rememberCoroutineScope()
                    GoogleMap(
                        modifier = Modifier.fillMaxWidth().height(300.dp),
                        cameraPositionState = cameraPositionState,
                        properties = MapProperties(mapType = MapType.NORMAL),
                        uiSettings = MapUiSettings(zoomControlsEnabled = true),
                        onMapClick = { latLng ->
                            markerPosition = latLng
                            latitude = latLng.latitude
                            longitude = latLng.longitude
                            scope.launch {
                                try {
                                    val geocoder = Geocoder(context, Locale.getDefault())
                                    val addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
                                    val address = addresses?.firstOrNull()
                                    val country = address?.countryName
                                    val region = address?.adminArea
                                    val city = address?.locality ?: address?.subAdminArea
                                    val street = address?.thoroughfare
                                    val parts = listOfNotNull(country, region, city, street)
                                    location = if (parts.isNotEmpty()) parts.joinToString(", ") else "Lat: ${latLng.latitude}, Lng: ${latLng.longitude}"
                                } catch (e: Exception) {
                                    location = "Lat: ${latLng.latitude}, Lng: ${latLng.longitude}"
                                }
                            }
                        }
                    ) {
                        markerPosition?.let {
                            Marker(state = com.google.maps.android.compose.MarkerState(position = it))
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun DatePicker(
    selectedDate: Calendar,
    onDateSelected: (Calendar) -> Unit
) {
    val year = selectedDate.get(Calendar.YEAR)
    val month = selectedDate.get(Calendar.MONTH)
    val day = selectedDate.get(Calendar.DAY_OF_MONTH)

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        var yearValue by remember { mutableIntStateOf(year) }
        var monthValue by remember { mutableIntStateOf(month) }
        var dayValue by remember { mutableIntStateOf(day) }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Month", style = MaterialTheme.typography.labelSmall)
            var monthIndex by remember { mutableIntStateOf(month) }
            val monthNames = arrayOf(
                "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = {
                    monthIndex = (monthIndex - 1 + 12) % 12
                    monthValue = monthIndex
                    updateCalendar(selectedDate, yearValue, monthValue, dayValue, onDateSelected)
                }) {
                    Text("◀")
                }
                Text(monthNames[monthIndex], style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = {
                    monthIndex = (monthIndex + 1) % 12
                    monthValue = monthIndex
                    updateCalendar(selectedDate, yearValue, monthValue, dayValue, onDateSelected)
                }) {
                    Text("▶")
                }
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Day", style = MaterialTheme.typography.labelSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = {
                    dayValue = maxOf(1, dayValue - 1)
                    updateCalendar(selectedDate, yearValue, monthValue, dayValue, onDateSelected)
                }) {
                    Text("◀")
                }
                Text(dayValue.toString(), style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = {
                    val maxDay = Calendar.getInstance().apply {
                        set(yearValue, monthValue, 1)
                    }.getActualMaximum(Calendar.DAY_OF_MONTH)
                    dayValue = minOf(maxDay, dayValue + 1)
                    updateCalendar(selectedDate, yearValue, monthValue, dayValue, onDateSelected)
                }) {
                    Text("▶")
                }
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Year", style = MaterialTheme.typography.labelSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = {
                    yearValue--
                    updateCalendar(selectedDate, yearValue, monthValue, dayValue, onDateSelected)
                }) {
                    Text("◀")
                }
                Text(yearValue.toString(), style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = {
                    yearValue++
                    updateCalendar(selectedDate, yearValue, monthValue, dayValue, onDateSelected)
                }) {
                    Text("▶")
                }
            }
        }
    }
}

@Composable
fun TimePicker(
    selectedTime: Calendar,
    onTimeSelected: (Calendar) -> Unit
) {
    var hour by remember { mutableIntStateOf(selectedTime.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember { mutableIntStateOf(selectedTime.get(Calendar.MINUTE)) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Hour", style = MaterialTheme.typography.labelSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = {
                    hour = (hour - 1 + 24) % 24
                    updateTimeCalendar(selectedTime, hour, minute, onTimeSelected)
                }) {
                    Text("◀")
                }
                Text(String.format("%02d", hour), style = MaterialTheme.typography.titleLarge)
                IconButton(onClick = {
                    hour = (hour + 1) % 24
                    updateTimeCalendar(selectedTime, hour, minute, onTimeSelected)
                }) {
                    Text("▶")
                }
            }
        }

        Text(":", style = MaterialTheme.typography.titleLarge)

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Minute", style = MaterialTheme.typography.labelSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = {
                    minute = (minute - 10 + 60) % 60
                    updateTimeCalendar(selectedTime, hour, minute, onTimeSelected)
                }) {
                    Text("◀")
                }
                Text(String.format("%02d", minute), style = MaterialTheme.typography.titleLarge)
                IconButton(onClick = {
                    minute = (minute + 10) % 60
                    updateTimeCalendar(selectedTime, hour, minute, onTimeSelected)
                }) {
                    Text("▶")
                }
            }
        }
    }
}

private fun updateCalendar(
    calendar: Calendar,
    year: Int,
    month: Int,
    day: Int,
    onDateSelected: (Calendar) -> Unit
) {
    calendar.set(year, month, day)
    onDateSelected(calendar.clone() as Calendar)
}

private fun updateTimeCalendar(
    calendar: Calendar,
    hour: Int,
    minute: Int,
    onTimeSelected: (Calendar) -> Unit
) {
    calendar.set(Calendar.HOUR_OF_DAY, hour)
    calendar.set(Calendar.MINUTE, minute)
    onTimeSelected(calendar.clone() as Calendar)
}


