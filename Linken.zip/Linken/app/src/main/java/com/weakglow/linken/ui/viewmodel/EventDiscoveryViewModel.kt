﻿package com.weakglow.linken.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import android.content.Context
import com.weakglow.linken.data.ExternalEvent
import com.weakglow.linken.service.EventDiscoveryService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class EventDiscoveryUiState(
    val events: List<ExternalEvent> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class EventDiscoveryViewModel(
    context: Context? = null
) : ViewModel() {
    private val discoveryService: EventDiscoveryService = EventDiscoveryService(context)
    
    private val _uiState = MutableStateFlow(EventDiscoveryUiState())
    val uiState: StateFlow<EventDiscoveryUiState> = _uiState.asStateFlow()
    
    enum class SortOption { DATE_ASC, DATE_DESC, NEAREST }
    private val _sortOption = MutableStateFlow(SortOption.DATE_ASC)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()
    
    private val _sortedEvents = MutableStateFlow<List<ExternalEvent>>(emptyList())
    val sortedEvents: StateFlow<List<ExternalEvent>> = _sortedEvents.asStateFlow()
    

    init {
        discoverEvents()
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(15 * 60 * 1000)
                refreshEvents(System.currentTimeMillis())
            }
        }
    }

    fun discoverEvents(targetDate: Long = System.currentTimeMillis(), daysRange: Int = 30) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            try {
                val events = discoveryService.findClosestEvents(targetDate, daysRange)
                _uiState.value = _uiState.value.copy(
                    events = events,
                    isLoading = false
                )
                val normalized = events.map { it.copy(category = normalizeCategory(it)) }
                applySorting(normalized, _sortOption.value)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = e.message ?: "Failed to discover events"
                )
            }
        }
    }
    
    fun refreshEvents(targetDate: Long = System.currentTimeMillis()) {
        discoverEvents(targetDate)
    }

    fun setSortOption(option: SortOption) {
        _sortOption.value = option
        val normalized = _uiState.value.events.map { it.copy(category = normalizeCategory(it)) }
        applySorting(normalized, option)
    }

    private fun applySorting(events: List<ExternalEvent>, option: SortOption) {
        val sorted = when (option) {
            SortOption.DATE_ASC -> events.sortedBy { it.dateTime }
            SortOption.DATE_DESC -> events.sortedByDescending { it.dateTime }
            SortOption.NEAREST -> {
                val base = getUserLocation() ?: Pair(54.6872, 25.2797)
                events.sortedBy { distanceKm(base.first, base.second, it.latitude, it.longitude) }
            }
        }
        _sortedEvents.value = sorted
    }

    private fun normalizeCategory(event: ExternalEvent): String {
        val c = event.category.lowercase()
        return when {
            c.contains("metal") -> "Underground (metal)"
            c.contains("concert") || c.contains("music") || c.contains("festival") -> "Concerts"
            c.contains("club") || c.contains("nightlife") -> "Clubs"
            c.contains("meetup") || c.contains("meeting") -> "Meetings"
            else -> "Gatherings"
        }
    }

    private fun getUserLocation(): Pair<Double, Double>? = null

    private fun distanceKm(lat1: Double, lon1: Double, lat2: Double?, lon2: Double?): Double {
        if (lat2 == null || lon2 == null) return Double.MAX_VALUE
        val R = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
                kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
                kotlin.math.sin(dLon / 2) * kotlin.math.sin(dLon / 2)
        val c = 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
        return R * c
    }
}


