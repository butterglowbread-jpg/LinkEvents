﻿package com.weakglow.linken.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.weakglow.linken.ui.viewmodel.SettingsViewModel
import com.weakglow.linken.ui.viewmodel.EventViewModel
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import coil.compose.SubcomposeAsyncImage
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    navController: NavController,
    eventViewModel: com.weakglow.linken.ui.viewmodel.EventViewModel,
    settingsViewModel: SettingsViewModel
) {
    val settings = settingsViewModel
    val context = androidx.compose.ui.platform.LocalContext.current
    val darkMode by settings.isDarkMode.collectAsState()
    val language by settings.language.collectAsState()
    val isLoggedIn by settings.isLoggedIn.collectAsState()
    val username by settings.username.collectAsState()
    val use24Hour by settings.use24Hour.collectAsState()
    val allEvents by eventViewModel.allEvents.collectAsState(initial = emptyList())
    val pastFavorited = remember(allEvents) { allEvents.filter { it.isFavorite && it.dateTime < System.currentTimeMillis() } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (language == "lt") "Nustatymai" else "Settings") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(if (language == "lt") "Išvaizda" else "Appearance", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (language == "lt") "Tamsi tema" else "Dark mode", modifier = Modifier.weight(1f))
                Switch(checked = darkMode, onCheckedChange = { settings.setDarkMode(it); com.weakglow.linken.ui.viewmodel.SettingsStorage.saveDarkMode(context, it) })
            }

            Text(if (language == "lt") "Laikas" else "Time", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (language == "lt") "24 val formatas" else "24-hour format", modifier = Modifier.weight(1f))
                Switch(checked = use24Hour, onCheckedChange = { settings.setUse24Hour(it); com.weakglow.linken.ui.viewmodel.SettingsStorage.saveUse24Hour(context, it) })
            }

            Text(if (language == "lt") "Kalba" else "Language", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = language == "lt",
                    onClick = { settings.setLanguage("lt"); com.weakglow.linken.ui.viewmodel.SettingsStorage.saveLanguage(context, "lt") },
                    label = {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            SubcomposeAsyncImage(
                                model = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Flag_of_Lithuania.svg/330px-Flag_of_Lithuania.svg.png",
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                                contentScale = ContentScale.Crop
                            )
                            Text("Lietuvių")
                        }
                    }
                )
                FilterChip(
                    selected = language == "en",
                    onClick = { settings.setLanguage("en"); com.weakglow.linken.ui.viewmodel.SettingsStorage.saveLanguage(context, "en") },
                    label = {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            SubcomposeAsyncImage(
                                model = "https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Flag_of_the_United_States_%28DDD-F-416E_specifications%29.svg/500px-Flag_of_the_United_States_%28DDD-F-416E_specifications%29.svg.png",
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                                contentScale = ContentScale.Crop
                            )
                            Text("English")
                        }
                    }
                )
            }

            Text(if (language == "lt") "Paskyra" else "Account", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text((if (language == "lt") "Statusas:" else "Status:") + " " + (if (isLoggedIn) (if (language == "lt") "Prisijungta" else "Logged in") else (if (language == "lt") "Neprisijungta" else "Logged out")))
                Button(onClick = { navController.navigate(com.weakglow.linken.ui.navigation.Screen.Auth.route) }) {
                    Text(if (language == "lt") "Atidaryti prisijungimą" else "Open Login")
                }
            }

            Text(if (language == "lt") "Archyvas" else "Archive", style = MaterialTheme.typography.titleMedium)
            if (pastFavorited.isEmpty()) {
                Text(if (language == "lt") "Nėra praeitų pamėgtų renginių" else "No past favorited events")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(pastFavorited, key = { it.id }) { ev ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(ev.title, style = MaterialTheme.typography.bodyLarge)
                                Text(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(java.util.Date(ev.dateTime)))
                            }
                        }
                    }
                }
            }
        }
    }
}

