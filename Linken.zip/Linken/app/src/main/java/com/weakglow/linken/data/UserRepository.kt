﻿package com.weakglow.linken.data

class UserRepository(private val userDao: UserDao) {
    suspend fun createUser(username: String, passwordHash: String): Long {
        val existing = userDao.getByUsername(username)
        if (existing != null) throw IllegalArgumentException("Username already exists")
        val user = User(username = username, passwordHash = passwordHash, createdAt = System.currentTimeMillis())
        return userDao.insert(user)
    }

    suspend fun findByUsername(username: String): User? = userDao.getByUsername(username)
}


