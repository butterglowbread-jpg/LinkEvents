﻿package com.weakglow.linken.ui.theme

import androidx.compose.ui.graphics.Color


val Purple80 = Color(0xFFE1BEE7) 
val PurpleGrey80 = Color(0xFFCE93D8) 
val Pink80 = Color(0xFFF8BBD0) 


val Purple40 = Color(0xFF7B1FA2) 
val PurpleGrey40 = Color(0xFF9C27B0) 
val Pink40 = Color(0xFFBA68C8) 


val PurpleAccent = Color(0xFFA027B6) 
val PurpleLight = Color(0xFFE1BEE7) 
val PurpleDark = Color(0xFF6A1B9A) 
val PurpleVibrant = Color(0xFFAB47BC) 
