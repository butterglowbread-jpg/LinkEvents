﻿package com.weakglow.linken.data


data class ExternalEvent(
    val id: String,
    val title: String,
    val description: String,
    val dateTime: Long, 
    val location: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val category: String = "General",
    val source: String, 
    val url: String? = null,
    val imageUrl: String? = null,
    val price: String? = null,
    val venueName: String? = null,
    val country: String? = null,
    val city: String? = null,
    val street: String? = null,
    val postalCode: String? = null,
    val organizer: String? = null,
    val organizerId: String? = null,
    val status: String? = null,
    val timezone: String? = null,
    val minPrice: String? = null,
    val maxPrice: String? = null,
    val ticketsUrl: String? = null
)

