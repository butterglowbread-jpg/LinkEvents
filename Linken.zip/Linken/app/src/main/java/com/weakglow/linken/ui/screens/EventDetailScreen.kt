﻿package com.weakglow.linken.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.SubcomposeAsyncImage
import coil.compose.SubcomposeAsyncImageContent
import com.weakglow.linken.data.Event
import com.weakglow.linken.ui.navigation.Screen
import com.weakglow.linken.ui.viewmodel.EventViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventDetailScreen(
    navController: NavController,
    viewModel: EventViewModel,
    settingsViewModel: com.weakglow.linken.ui.viewmodel.SettingsViewModel,
    eventId: Long
) {
    var event by remember { mutableStateOf<Event?>(null) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(eventId) {
        event = viewModel.getEventById(eventId)
    }
    
    
    val allEvents by viewModel.allEvents.collectAsState(initial = emptyList())
    LaunchedEffect(allEvents) {
        event = allEvents.find { it.id == eventId } ?: event
    }

    if (event == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = androidx.compose.ui.Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    val eventNonNull = event!!
    val use24Hour by settingsViewModel.use24Hour.collectAsState()
    val dateFormat = if (use24Hour) SimpleDateFormat("EEEE, MMMM d, yyyy 'at' HH:mm", Locale.getDefault()) else SimpleDateFormat("EEEE, MMMM d, yyyy 'at' h:mm a", Locale.getDefault())
    val dateString = dateFormat.format(Date(eventNonNull.dateTime))
    val eventLink = eventNonNull.sourceUrl
    LaunchedEffect(eventNonNull.id) {
        if (eventNonNull.imageUrl == null && (eventNonNull.location != null || eventNonNull.latitude != null)) {
            viewModel.updateEvent(eventNonNull)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Event Details") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.toggleFavorite(eventNonNull)
                        }
                    ) {
                        Icon(
                            if (eventNonNull.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (eventNonNull.isFavorite) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(
                        onClick = {
                            viewModel.addEventToCalendar(eventNonNull)
                        }
                    ) {
                        Icon(
                            Icons.Default.CalendarToday,
                            contentDescription = "Add to Calendar",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = {
                            navController.navigate(Screen.AddEdit.createRoute(eventId))
                        }
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(
                        onClick = { showDeleteDialog = true }
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        val configuration = androidx.compose.ui.platform.LocalConfiguration.current
        val bannerHeight = (configuration.screenHeightDp.dp / 4)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(bannerHeight)
            ) {
                val imgUrl = eventNonNull.imageUrl
                if (imgUrl != null) {
                    SubcomposeAsyncImage(
                        model = imgUrl,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant))
                }
            }
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text = eventNonNull.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(dateString, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (eventNonNull.location != null) {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("📍 ${eventNonNull.location}", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = {
                            runCatching {
                                val lat = eventNonNull.latitude
                                val lon = eventNonNull.longitude
                                val uri = if (lat != null && lon != null) {
                                    android.net.Uri.parse("geo:$lat,$lon?q=$lat,$lon(${android.net.Uri.encode(eventNonNull.title)})")
                                } else {
                                    android.net.Uri.parse("https://www.google.com/maps/search/?api=1&query=${android.net.Uri.encode(eventNonNull.location!!)}")
                                }
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, uri)
                                context.startActivity(intent)
                            }
                        }) { Text("Open in Maps") }
                    }
                }

                val context = androidx.compose.ui.platform.LocalContext.current
                var marker by remember { mutableStateOf<com.google.android.gms.maps.model.LatLng?>(
                    if (eventNonNull.latitude != null && eventNonNull.longitude != null) com.google.android.gms.maps.model.LatLng(eventNonNull.latitude!!, eventNonNull.longitude!!) else null
                ) }
                if (marker == null && eventNonNull.location != null) {
                    LaunchedEffect(eventNonNull.location) {
                        runCatching {
                            val geo = android.location.Geocoder(context, java.util.Locale.getDefault())
                            val res = geo.getFromLocationName(eventNonNull.location!!, 1)
                            val addr = res?.firstOrNull()
                            if (addr != null) marker = com.google.android.gms.maps.model.LatLng(addr.latitude, addr.longitude)
                        }
                    }
                }
                if (marker != null) {
                    val cameraPositionState = com.google.maps.android.compose.rememberCameraPositionState {
                        position = com.google.android.gms.maps.model.CameraPosition.fromLatLngZoom(marker!!, 15f)
                    }
                    com.google.maps.android.compose.GoogleMap(
                        modifier = Modifier.fillMaxWidth().height(200.dp),
                        cameraPositionState = cameraPositionState,
                        onMapLoaded = {},
                        uiSettings = com.google.maps.android.compose.MapUiSettings(zoomControlsEnabled = false)
                    ) {
                        com.google.maps.android.compose.Marker(state = com.google.maps.android.compose.rememberMarkerState(position = marker!!))
                    }
                }

                
                if (eventNonNull.description.isNotEmpty()) {
                    Text(eventNonNull.description, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Event") },
            text = { Text("Are you sure you want to delete \"${eventNonNull.title}\"? This action cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            viewModel.deleteEventById(eventId)
                            navController.popBackStack()
                        }
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}


