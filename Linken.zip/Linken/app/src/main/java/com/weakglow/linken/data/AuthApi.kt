﻿package com.weakglow.linken.data

import retrofit2.http.Body
import retrofit2.http.POST

data class LoginRequest(val username: String, val password: String)
data class SignupRequest(val username: String, val password: String)
data class AuthResponse(val success: Boolean, val token: String?)

interface AuthApi {
    @POST("/api/auth/login")
    suspend fun login(@Body req: LoginRequest): AuthResponse

    @POST("/api/auth/signup")
    suspend fun signup(@Body req: SignupRequest): AuthResponse
}


