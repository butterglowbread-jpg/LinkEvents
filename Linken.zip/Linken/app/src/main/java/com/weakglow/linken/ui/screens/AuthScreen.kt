﻿package com.weakglow.linken.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.weakglow.linken.ui.viewmodel.SettingsViewModel
import kotlinx.coroutines.launch
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.tasks.await

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    navController: NavController,
    settingsViewModel: SettingsViewModel
) {
    val language by settingsViewModel.language.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (language == "lt") "Prisijungimas" else "Authentication") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text(if (language == "lt") "Vartotojo vardas" else "Username") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text(if (language == "lt") "Slaptažodis" else "Password") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            if (error != null) {
                Text(error!!, color = MaterialTheme.colorScheme.error)
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(onClick = {
                    scope.launch {
                        try {
                            if (!username.contains("@")) {
                                error = if (language == "lt") "Įveskite el. pašto adresą" else "Enter a valid email"
                                return@launch
                            }
                            FirebaseAuth.getInstance().createUserWithEmailAndPassword(username, password).await()
                            settingsViewModel.setUsername(username)
                            com.weakglow.linken.ui.viewmodel.SettingsStorage.saveUsername(context, username)
                            settingsViewModel.setLoggedIn(true)
                            com.weakglow.linken.ui.viewmodel.SettingsStorage.saveLoggedIn(context, true)
                            error = null
                            navController.popBackStack()
                        } catch (e: Exception) {
                            error = e.message ?: "Failed to sign up"
                        }
                    }
                }) {
                    Text(if (language == "lt") "Registruotis" else "Sign Up")
                }
                Button(onClick = {
                    scope.launch {
                        try {
                            if (!username.contains("@")) {
                                error = if (language == "lt") "Įveskite el. pašto adresą" else "Enter a valid email"
                                return@launch
                            }
                            FirebaseAuth.getInstance().signInWithEmailAndPassword(username, password).await()
                                settingsViewModel.setUsername(username)
                                com.weakglow.linken.ui.viewmodel.SettingsStorage.saveUsername(context, username)
                                settingsViewModel.setLoggedIn(true)
                                com.weakglow.linken.ui.viewmodel.SettingsStorage.saveLoggedIn(context, true)
                                error = null
                                navController.popBackStack()
                        } catch (e: Exception) {
                            error = e.message ?: "Failed to log in"
                        }
                    }
                }) {
                    Text(if (language == "lt") "Prisijungti" else "Log In")
                }
            }
        }
    }
}

