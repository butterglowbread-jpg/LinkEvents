﻿package com.weakglow.linken.ui.viewmodel

import android.content.Context

object SettingsStorage {
    private const val PREFS = "app_settings"
    private const val KEY_DARK = "dark_mode"
    private const val KEY_LANG = "language"
    private const val KEY_LOGGED_IN = "logged_in"
    private const val KEY_USERNAME = "username"
    private const val KEY_24H = "use_24_hour"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun loadDarkMode(context: Context): Boolean = prefs(context).getBoolean(KEY_DARK, false)
    fun loadLanguage(context: Context): String = prefs(context).getString(KEY_LANG, "en") ?: "en"
    fun loadLoggedIn(context: Context): Boolean = prefs(context).getBoolean(KEY_LOGGED_IN, false)
    fun loadUsername(context: Context): String = prefs(context).getString(KEY_USERNAME, "") ?: ""
    fun loadUse24Hour(context: Context): Boolean = prefs(context).getBoolean(KEY_24H, true)

    fun saveDarkMode(context: Context, value: Boolean) { prefs(context).edit().putBoolean(KEY_DARK, value).apply() }
    fun saveLanguage(context: Context, value: String) { prefs(context).edit().putString(KEY_LANG, value).apply() }
    fun saveLoggedIn(context: Context, value: Boolean) { prefs(context).edit().putBoolean(KEY_LOGGED_IN, value).apply() }
    fun saveUsername(context: Context, value: String) { prefs(context).edit().putString(KEY_USERNAME, value).apply() }
    fun saveUse24Hour(context: Context, value: Boolean) { prefs(context).edit().putBoolean(KEY_24H, value).apply() }
}

