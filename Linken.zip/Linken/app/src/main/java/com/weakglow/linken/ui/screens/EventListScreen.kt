﻿package com.weakglow.linken.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import coil.compose.SubcomposeAsyncImage
import coil.compose.SubcomposeAsyncImageContent
import androidx.compose.ui.graphics.Color as UiColor
import androidx.navigation.NavController
import com.weakglow.linken.data.Event
import com.weakglow.linken.ui.navigation.Screen
import com.weakglow.linken.ui.viewmodel.EventViewModel
import java.text.SimpleDateFormat
import java.util.*
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EventListScreen(
    navController: NavController,
    viewModel: EventViewModel,
    settingsViewModel: com.weakglow.linken.ui.viewmodel.SettingsViewModel
) {
    val events by viewModel.allEvents.collectAsState(initial = emptyList())
    val visibleEvents = remember(events) { events }
    var sortOption by remember { mutableStateOf(SortOption.DATE_ASC) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val userLocation = remember {
        val lm = context.getSystemService(android.content.Context.LOCATION_SERVICE) as android.location.LocationManager
        val providers = lm.getProviders(true)
        val loc = providers.mapNotNull { provider ->
            try { lm.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
        }.maxByOrNull { it.time }
        if (loc != null) Pair(loc.latitude, loc.longitude) else Pair(54.6872, 25.2797)
    }
    LaunchedEffect(Unit) { viewModel.deletePastEvents() }

    val language by settingsViewModel.language.collectAsState()
    if (events.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = if (language == "lt") "Dar nėra renginių" else "No events yet",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (language == "lt") "Paspauskite + mygtuką, kad pridėtumėte pirmą renginį" else "Tap the + button to add your first event",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    } else {
        val sortedEvents = when (sortOption) {
            SortOption.DATE_ASC -> visibleEvents.sortedBy { it.dateTime }
            SortOption.NEAREST -> visibleEvents.sortedBy { distanceKm(userLocation.first, userLocation.second, it.latitude, it.longitude) }
            SortOption.FAVORITES -> visibleEvents.sortedBy { it.dateTime }
        }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (language == "lt") "Rikiuoti" else "Sort",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FilterChip(
                        selected = sortOption == SortOption.DATE_ASC,
                        onClick = { sortOption = SortOption.DATE_ASC },
                        label = { Text(if (language == "lt") "Data ↑" else "Date ↑") }
                    )
                    FilterChip(
                        selected = sortOption == SortOption.FAVORITES,
                        onClick = { sortOption = SortOption.FAVORITES },
                        label = { Text(if (language == "lt") "Mėgstamiausi" else "Favorites") }
                    )
                    FilterChip(
                        selected = sortOption == SortOption.NEAREST,
                        onClick = { sortOption = SortOption.NEAREST },
                        label = { Text(if (language == "lt") "Arčiausi" else "Nearest") }
                    )
                    if (!hasLocationPermission) {
                        TextButton(onClick = {
                            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                        }) {
                            Text(if (language == "lt") "Įjungti vietą" else "Enable Location")
                        }
                    }
                }
            }
            
            
            items(sortedEvents, key = { it.id }) { event ->
                EventCard(
                    event = event,
                    use24Hour = settingsViewModel.use24Hour.collectAsState().value,
                    onEventClick = {
                        navController.navigate(Screen.Detail.createRoute(event.id))
                    },
                    onDelete = {
                        viewModel.deleteEvent(event)
                    }
                )
            }
        }
    }
}

enum class SortOption { DATE_ASC, NEAREST, FAVORITES }

private fun distanceKm(lat1: Double, lon1: Double, lat2: Double?, lon2: Double?): Double {
    if (lat2 == null || lon2 == null) return Double.MAX_VALUE
    val R = 6371.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
            kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
            kotlin.math.sin(dLon / 2) * kotlin.math.sin(dLon / 2)
    val c = 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
    return R * c
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventCard(
    event: Event,
    use24Hour: Boolean,
    onEventClick: () -> Unit,
    onDelete: () -> Unit
) {
    var showDelete by remember { mutableStateOf(false) }
    val timeFormat = if (use24Hour) SimpleDateFormat("HH:mm", Locale.getDefault()) else SimpleDateFormat("h:mm a", Locale.getDefault())
    val timeString = timeFormat.format(Date(event.dateTime))

    Card(
        onClick = onEventClick,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 80.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val bannerHeight = 140.dp
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(bannerHeight)
                    .clip(RoundedCornerShape(12.dp))
            ) {
                val imgUrl = event.imageUrl
                if (imgUrl != null) {
                    SubcomposeAsyncImage(
                        model = imgUrl,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        loading = {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(
                                                genreColor(normalizeCategory(event.category)),
                                                MaterialTheme.colorScheme.surfaceVariant
                                            )
                                        )
                                    )
                            ) { Text(text = genreEmoji(normalizeCategory(event.category)), modifier = Modifier.align(Alignment.Center)) }
                        },
                        error = {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(
                                                genreColor(normalizeCategory(event.category)),
                                                MaterialTheme.colorScheme.surfaceVariant
                                            )
                                        )
                                    )
                            ) { Text(text = genreEmoji(normalizeCategory(event.category)), modifier = Modifier.align(Alignment.Center)) }
                        }
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        genreColor(normalizeCategory(event.category)),
                                        MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )
                            )
                    ) { Text(text = genreEmoji(normalizeCategory(event.category)), modifier = Modifier.align(Alignment.Center)) }
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(IntrinsicSize.Max)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color(event.color))
                )

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onEventClick() }
                )
                if (event.description.isNotEmpty()) {
                    Text(
                        text = event.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = timeString,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (event.category.isNotEmpty()) {
                        Surface(
                            color = genreColor(normalizeCategory(event.category)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = normalizeCategory(event.category),
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = contrastingOnColor(genreColor(normalizeCategory(event.category)))
                            )
                        }
                    }
                }
                EventCountdown(eventDateTime = event.dateTime)
            }
                IconButton(onClick = { showDelete = !showDelete }) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }

    AnimatedVisibility(visible = showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete Event") },
            text = { Text("Are you sure you want to delete this event?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDelete()
                        showDelete = false
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDelete = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun EventCountdown(eventDateTime: Long) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(eventDateTime) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            now = System.currentTimeMillis()
        }
    }
    val remaining = (eventDateTime - now).coerceAtLeast(0)
    val days = remaining / (1000L * 60 * 60 * 24)
    val hours = (remaining % (1000L * 60 * 60 * 24)) / (1000L * 60 * 60)
    val minutes = (remaining % (1000L * 60 * 60)) / (1000L * 60)
    val seconds = (remaining % (1000L * 60)) / 1000L
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            @Composable
            fun UnitBox(label: String, value: String) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = value,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
            UnitBox("Days", days.toString())
            UnitBox("Hours", hours.toString())
            UnitBox("Min", minutes.toString())
            UnitBox("Sec", seconds.toString())
        }
    }
}

private fun genreColor(category: String): Color {
    return when (category) {
        "Underground (metal)" -> Color(0xFF5E60CE)
        "Concerts" -> Color(0xFF7B1FA2)
        "Clubs" -> Color(0xFF4EA8DE)
        "Meetings" -> Color(0xFF9D8DF1)
        "Gatherings" -> Color(0xFFB8C0FF)
        else -> Color(0xFFA7A7B7)
    }
}

private fun contrastingOnColor(bg: Color): Color {
    val r = bg.red
    val g = bg.green
    val b = bg.blue
    val luminance = 0.299f * r + 0.587f * g + 0.114f * b
    return if (luminance > 0.5f) Color.Black else Color.White
}

private fun normalizeCategory(name: String): String {
    val c = name.lowercase()
    return when {
        c.contains("metal") -> "Underground (metal)"
        c.contains("concert") || c.contains("music") || c.contains("festival") -> "Concerts"
        c.contains("club") || c.contains("nightlife") -> "Clubs"
        c.contains("meetup") || c.contains("meeting") -> "Meetings"
        else -> "Gatherings"
    }
}

private fun genreEmoji(category: String): String {
    return when (category) {
        "Underground (metal)" -> "🎸"
        "Gatherings" -> "🫂"
        "Clubs" -> "🎧"
        "Concerts" -> "🎵"
        "Meetings" -> "📅"
        else -> "📍"
    }
}


