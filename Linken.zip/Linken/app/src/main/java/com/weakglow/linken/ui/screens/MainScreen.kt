﻿package com.weakglow.linken.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.weakglow.linken.ui.navigation.Screen
import androidx.compose.ui.platform.LocalContext
import com.weakglow.linken.ui.theme.PurpleAccent
import com.weakglow.linken.ui.viewmodel.EventViewModel
import com.weakglow.linken.ui.viewmodel.SettingsViewModel
import androidx.compose.ui.res.painterResource
import com.weakglow.linken.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    navController: NavController,
    viewModel: EventViewModel,
    settingsViewModel: SettingsViewModel
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val appContext = LocalContext.current.applicationContext
    val discoveryViewModel = remember { com.weakglow.linken.ui.viewmodel.EventDiscoveryViewModel(appContext) }
    val discoveryUiState by discoveryViewModel.uiState.collectAsState()
    val storedEvents by viewModel.allEvents.collectAsState(initial = emptyList())
    val isLoggedIn by settingsViewModel.isLoggedIn.collectAsState()
    val language by settingsViewModel.language.collectAsState()

    LaunchedEffect(Unit) {
        discoveryViewModel.discoverEvents(daysRange = 365)
        
        if (storedEvents.none { it.title.contains("STARTUOLIŲ DŽIUNGLĖS") }) {
            viewModel.insertStartupEvent()
        }
        if (storedEvents.none { it.title.contains("IR VISA TAI KAS YRA GRAŽU YRA GRAŽU") }) {
            viewModel.insertIvtkygygEvent()
        }
        if (storedEvents.none { it.title.contains("❄️🎾 ŠVENTINIS PADELIO IR TENISO TURNYRAS") || it.title.contains("KALĖDZINIS SERVAS") }) {
            viewModel.insertKaledzinisServasEvent()
        }
        if (storedEvents.none { it.title.contains("KALĖDŲ SENELIS KVIEČIA PASISVEČIUOTI") }) {
            viewModel.insertKaleduSenelisEvents()
        }
    }

    val tabs = if (language == "lt") listOf("Sąrašas", "Kalendorius", "Žemėlapis") else listOf("List", "Calendar", "Map")
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val logoRes = remember { appContext.resources.getIdentifier("logo", "drawable", appContext.packageName) }
                        if (logoRes != 0) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_linkevents),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        } else {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Text(if (language == "lt") "LinkEvents" else "LinkEvents", fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    IconButton(
                        onClick = { navController.navigate(Screen.Discovery.route) }
                    ) {
                        Icon(
                            Icons.Default.Explore,
                            contentDescription = if (language == "lt") "Atrasti renginius" else "Discover Events",
                            tint = PurpleAccent
                        )
                    }
                    if (!isLoggedIn) {
                        TextButton(onClick = { navController.navigate(Screen.Auth.route) }) {
                            Text(if (language == "lt") "Prisijungti" else "Log In")
                        }
                    }
                    IconButton(
                        onClick = { navController.navigate(Screen.Settings.route) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = if (language == "lt") "Nustatymai" else "Settings",
                            tint = PurpleAccent
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            if (selectedTabIndex == 0) {
                FloatingActionButton(
                    onClick = {
                        navController.navigate(Screen.AddEdit.createRoute())
                    },
                    containerColor = PurpleAccent,
                    modifier = Modifier.size(64.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Event"
                    )
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            TabRow(selectedTabIndex = selectedTabIndex) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title) }
                    )
                }
            }

            when (selectedTabIndex) {
                0 -> EventListScreen(navController = navController, viewModel = viewModel, settingsViewModel = settingsViewModel)
                1 -> CalendarScreen(navController = navController, viewModel = viewModel)
                2 -> EventMapScreen(events = storedEvents)
            }
        }
    }
}


