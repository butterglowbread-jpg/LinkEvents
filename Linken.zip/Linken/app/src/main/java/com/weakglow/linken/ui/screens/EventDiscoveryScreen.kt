﻿package com.weakglow.linken.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.weakglow.linken.data.ExternalEvent
import com.weakglow.linken.data.Event
import com.weakglow.linken.ui.theme.PurpleAccent
import com.weakglow.linken.ui.viewmodel.EventDiscoveryViewModel
import com.weakglow.linken.ui.viewmodel.EventViewModel
import java.text.SimpleDateFormat
import java.util.*
import android.content.Intent
import android.net.Uri
import com.weakglow.linken.BuildConfig
import androidx.compose.ui.graphics.Brush
import coil.compose.SubcomposeAsyncImage
import coil.compose.SubcomposeAsyncImageContent
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EventDiscoveryScreen(
    navController: NavController,
    viewModel: EventDiscoveryViewModel,
    eventViewModel: EventViewModel? = null,
    settingsViewModel: com.weakglow.linken.ui.viewmodel.SettingsViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()
    val sortedEvents by viewModel.sortedEvents.collectAsState()
    
    
    LaunchedEffect(Unit) {
        viewModel.discoverEvents()
    }

    val language by settingsViewModel.language.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(if (language == "lt") "Atrasti renginius" else "Discover Events", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.refreshEvents() },
                        enabled = !uiState.isLoading
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = if (language == "lt") "Atnaujinti" else "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(
                            color = PurpleAccent
                        )
                        Text(
                            if (language == "lt") "Ieškoma renginių..." else "Discovering events...",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            
            uiState.errorMessage != null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            (if (language == "lt") "Klaida: " else "Error: ") + (uiState.errorMessage ?: ""),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.error
                        )
                        Button(
                            onClick = { viewModel.refreshEvents() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PurpleAccent
                            )
                        ) {
                            Text(if (language == "lt") "Bandyti dar kartą" else "Retry")
                        }
                    }
                }
            }
            
            uiState.events.isEmpty() -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            if (language == "lt") "Renginių nerasta" else "No events found",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            if (language == "lt") "Pakeiskite paieškos kriterijus" else "Try adjusting your search criteria",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            
            else -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (language == "lt") "Rikiuoti" else "Sort",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FilterChip(
                                selected = sortOption == EventDiscoveryViewModel.SortOption.DATE_ASC,
                                onClick = { viewModel.setSortOption(EventDiscoveryViewModel.SortOption.DATE_ASC) },
                                label = { Text(if (language == "lt") "Data ↑" else "Date ↑") }
                            )
                            FilterChip(
                                selected = sortOption == EventDiscoveryViewModel.SortOption.DATE_DESC,
                                onClick = { viewModel.setSortOption(EventDiscoveryViewModel.SortOption.DATE_DESC) },
                                label = { Text(if (language == "lt") "Data ↓" else "Date ↓") }
                            )
                            FilterChip(
                                selected = sortOption == EventDiscoveryViewModel.SortOption.NEAREST,
                                onClick = { viewModel.setSortOption(EventDiscoveryViewModel.SortOption.NEAREST) },
                                label = { Text(if (language == "lt") "Arčiausi" else "Nearest") }
                            )
                            if (!hasLocationPermission) {
                                TextButton(onClick = {
                                    permissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }) {
                                    Text(if (language == "lt") "Įjungti vietą" else "Enable Location")
                                }
                            }
                        }
                    }
                }

                    val itemsToShow = if (sortedEvents.isEmpty()) uiState.events else sortedEvents

                    var persisted by remember { mutableStateOf(false) }

                    
                    LaunchedEffect(itemsToShow) {
                        if (!persisted && eventViewModel != null) {
                            itemsToShow.forEach { ext ->
                                eventViewModel.upsertFromExternal(ext, favorite = false)
                            }
                            persisted = true
                        }
                    }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(itemsToShow) { event ->
                            DiscoveredEventCard(
                                event = event,
                                use24Hour = settingsViewModel.use24Hour.collectAsState().value,
                                eventViewModel = eventViewModel,
                                onFavoriteClick = { externalEvent ->
                                    eventViewModel?.let { vm ->
                                        vm.upsertFromExternal(externalEvent, favorite = true)
                                        vm.addEventToCalendar(
                                            Event(
                                                title = externalEvent.title,
                                                dateTime = externalEvent.dateTime,
                                                category = externalEvent.category
                                            )
                                        )
                                    }
                                }
                            )
                        }
                    }
                }

        }
    }
}

@Composable
fun DiscoveredEventCard(
    event: ExternalEvent,
    use24Hour: Boolean,
    eventViewModel: EventViewModel? = null,
    onFavoriteClick: (ExternalEvent) -> Unit = {}
) {
    val dateFormat = if (use24Hour) SimpleDateFormat("EEEE, MMMM d, yyyy 'at' HH:mm", Locale.getDefault()) else SimpleDateFormat("EEEE, MMMM d, yyyy 'at' h:mm a", Locale.getDefault())
    val dateString = dateFormat.format(Date(event.dateTime))
    var isFavorited by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val bannerHeight = 160.dp
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(bannerHeight)
                    .clip(RoundedCornerShape(12.dp))
            ) {
                val imgUrl = event.imageUrl
                if (imgUrl != null) {
                    SubcomposeAsyncImage(
                        model = imgUrl,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        loading = {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(
                                                genreColor(event.category),
                                                MaterialTheme.colorScheme.surfaceVariant
                                            )
                                        )
                                    )
                            )
                        },
                        error = {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(
                                                genreColor(event.category),
                                                MaterialTheme.colorScheme.surfaceVariant
                                            )
                                        )
                                    )
                            )
                        }
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        genreColor(event.category),
                                        MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = event.category,
                            style = MaterialTheme.typography.titleMedium,
                            color = contrastingOnColor(genreColor(event.category))
                        )
                    }
                }
            }
            
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(24.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(PurpleAccent)
                    )
                    Text(
                        text = event.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                
                
                Surface(
                    color = PurpleAccent.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = event.source,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        color = PurpleAccent
                    )
                }

                val trustedNames = remember { BuildConfig.TRUSTED_EVENTBRITE_ORGANIZER_NAMES.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() } }
                val trustedIds = remember { BuildConfig.TRUSTED_EVENTBRITE_ORGANIZER_IDS.split(",").map { it.trim() }.filter { it.isNotEmpty() } }
                val isTrusted = (event.organizerId != null && trustedIds.contains(event.organizerId)) || (event.organizer != null && trustedNames.contains(event.organizer!!.lowercase()))
                if (isTrusted) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Trusted",
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            }
            
            
            if (event.description.isNotEmpty()) {
                Text(
                    text = event.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = dateString,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                if (event.location != null) {
                    Text(
                        text = "📍 ${event.location}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                val addressParts = listOfNotNull(event.country, event.city, event.street, event.postalCode)
                if (addressParts.isNotEmpty()) {
                    Text(
                        text = addressParts.joinToString(", "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (event.venueName != null) {
                    Text(
                        text = "Venue: ${event.venueName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (event.organizer != null) {
                    Text(
                        text = "Organizer: ${event.organizer}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                val statusLine = listOfNotNull(event.status, event.timezone).joinToString(" • ")
                if (statusLine.isNotEmpty()) {
                    Text(
                        text = statusLine,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                EventCountdown(eventDateTime = event.dateTime)
            }
            
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF5E60CE),
                                    Color(0xFFB8C0FF)
                                )
                            )
                        )
                ) {
                    Text(
                        text = event.category,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        color = Color.White
                    )
                }
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (event.price != null) {
                        Text(
                            text = event.price,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = PurpleAccent
                        )
                    }
                    val priceRange = listOfNotNull(event.minPrice, event.maxPrice).joinToString(" – ")
                    if (priceRange.isNotEmpty()) {
                        Text(
                            text = priceRange,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    
                    
                    
                    if (eventViewModel != null) {
                        IconButton(
                            onClick = {
                                isFavorited = !isFavorited
                                onFavoriteClick(event)
                            }
                        ) {
                            Icon(
                                if (isFavorited) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Add to Favorites",
                                tint = if (isFavorited) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EventCountdown(eventDateTime: Long) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(eventDateTime) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            now = System.currentTimeMillis()
        }
    }
    val remaining = (eventDateTime - now).coerceAtLeast(0)
    val days = remaining / (1000L * 60 * 60 * 24)
    val hours = (remaining % (1000L * 60 * 60 * 24)) / (1000L * 60 * 60)
    val minutes = (remaining % (1000L * 60 * 60)) / (1000L * 60)
    val seconds = (remaining % (1000L * 60)) / 1000L
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            @Composable
            fun UnitBox(label: String, value: String) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = value,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
            UnitBox("Days", days.toString())
            UnitBox("Hours", hours.toString())
            UnitBox("Min", minutes.toString())
            UnitBox("Sec", seconds.toString())
        }
    }
}

private fun genreColor(category: String): Color {
    return when (category) {
        "Underground (metal)" -> Color(0xFF5E60CE)
        "Concerts" -> Color(0xFF7B1FA2)
        "Clubs" -> Color(0xFF4EA8DE)
        "Meetings" -> Color(0xFF9D8DF1)
        "Gatherings" -> Color(0xFFB8C0FF)
        else -> Color(0xFFA7A7B7)
    }
}

private fun contrastingOnColor(bg: Color): Color {
    val r = bg.red
    val g = bg.green
    val b = bg.blue
    val luminance = 0.299f * r + 0.587f * g + 0.114f * b
    return if (luminance > 0.5f) Color.Black else Color.White
}


