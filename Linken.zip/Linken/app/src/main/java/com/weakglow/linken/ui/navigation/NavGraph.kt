﻿package com.weakglow.linken.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.weakglow.linken.data.Event
import com.weakglow.linken.ui.screens.AddEditEventScreen
import com.weakglow.linken.ui.screens.CalendarScreen
import com.weakglow.linken.ui.screens.EventDetailScreen
import com.weakglow.linken.ui.screens.EventDiscoveryScreen
import com.weakglow.linken.ui.screens.EventListScreen
import com.weakglow.linken.ui.screens.MainScreen
import com.weakglow.linken.ui.viewmodel.EventDiscoveryViewModel
import com.weakglow.linken.ui.viewmodel.EventViewModel

sealed class Screen(val route: String) {
    object Main : Screen("main")
    object List : Screen("list")
    object Calendar : Screen("calendar")
    object Discovery : Screen("discovery")
    object Settings : Screen("settings")
    object Auth : Screen("auth")
    object AddEdit : Screen("add_edit/{eventId}") {
        fun createRoute(eventId: Long? = null) = if (eventId != null) "add_edit/$eventId" else "add_edit/-1"
    }
    object Detail : Screen("detail/{eventId}") {
        fun createRoute(eventId: Long) = "detail/$eventId"
    }
}

@Composable
fun NavGraph(
    navController: NavHostController,
    viewModel: EventViewModel,
    discoveryViewModel: EventDiscoveryViewModel = EventDiscoveryViewModel(),
    startDestination: String = Screen.Main.route,
    settingsViewModel: com.weakglow.linken.ui.viewmodel.SettingsViewModel
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Screen.Main.route) {
            MainScreen(
                navController = navController,
                viewModel = viewModel,
                settingsViewModel = settingsViewModel
            )
        }
        
        composable(Screen.List.route) {
            EventListScreen(
                navController = navController,
                viewModel = viewModel,
                settingsViewModel = settingsViewModel
            )
        }
        
        composable(Screen.Calendar.route) {
            CalendarScreen(
                navController = navController,
                viewModel = viewModel
            )
        }
        
        composable(Screen.Discovery.route) {
            EventDiscoveryScreen(
                navController = navController,
                viewModel = discoveryViewModel,
                eventViewModel = viewModel,
                settingsViewModel = settingsViewModel
            )
        }
        composable(Screen.Settings.route) {
            com.weakglow.linken.ui.screens.SettingsScreen(
                navController = navController,
                eventViewModel = viewModel,
                settingsViewModel = settingsViewModel
            )
        }
        composable(Screen.Auth.route) {
            com.weakglow.linken.ui.screens.AuthScreen(
                navController = navController,
                settingsViewModel = settingsViewModel
            )
        }
        
        composable(Screen.AddEdit.route) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId")?.toLongOrNull() ?: -1L
            AddEditEventScreen(
                navController = navController,
                viewModel = viewModel,
                eventId = if (eventId == -1L) null else eventId
            )
        }
        
        composable(Screen.Detail.route) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId")?.toLongOrNull() ?: -1L
            EventDetailScreen(
                navController = navController,
                viewModel = viewModel,
                settingsViewModel = settingsViewModel,
                eventId = eventId
            )
        }
    }
}


