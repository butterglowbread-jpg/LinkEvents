﻿package com.weakglow.linken.service

import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import android.net.Uri
import com.weakglow.linken.data.Event
import java.util.Calendar


class CalendarService(private val context: Context) {
    
    
    fun addEventToCalendar(event: Event): Long? {
        try {
            val calendar = Calendar.getInstance().apply {
                timeInMillis = event.dateTime
            }
            
            val startMillis = calendar.timeInMillis
            
            calendar.add(Calendar.HOUR_OF_DAY, 1)
            val endMillis = calendar.timeInMillis
            
            val values = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, startMillis)
                put(CalendarContract.Events.DTEND, endMillis)
                put(CalendarContract.Events.TITLE, event.title)
                put(CalendarContract.Events.DESCRIPTION, event.description)
                put(CalendarContract.Events.CALENDAR_ID, getDefaultCalendarId())
                put(CalendarContract.Events.EVENT_TIMEZONE, Calendar.getInstance().timeZone.id)
                
                
                event.location?.let {
                    put(CalendarContract.Events.EVENT_LOCATION, it)
                }
                
                
                put(CalendarContract.Events.EVENT_COLOR, event.color.toInt())
            }
            
            val uri: Uri? = context.contentResolver.insert(
                CalendarContract.Events.CONTENT_URI,
                values
            )
            
            return uri?.lastPathSegment?.toLongOrNull()
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
    
    
    private fun getDefaultCalendarId(): Long {
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.IS_PRIMARY
        )
        
        val selection = "${CalendarContract.Calendars.IS_PRIMARY} = 1"
        
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            selection,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idIndex = cursor.getColumnIndex(CalendarContract.Calendars._ID)
                if (idIndex >= 0) {
                    return cursor.getLong(idIndex)
                }
            }
        }
        
        
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idIndex = cursor.getColumnIndex(CalendarContract.Calendars._ID)
                if (idIndex >= 0) {
                    return cursor.getLong(idIndex)
                }
            }
        }
        
        
        return 1L
    }
    
    
    fun hasCalendarPermission(): Boolean {
        
        
        return true
    }
}


