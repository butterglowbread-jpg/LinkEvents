Logo setup and usage

To use a custom logo in the app top bar, place a 1:1 logo image into the project's resources as `app/src/main/res/drawable/logo.png`.

Options:
1) Manual upload — copy your `logo.png` file into `app/src/main/res/drawable/logo.png`.
2) Automated download — run the following if you have the image available via a public URL:

   PowerShell (Windows):
   ```powershell
   cd <path to project root>
   .\scripts\download_logo.ps1 -url "https://example.com/path/to/logo.png"
   ```

   Bash (Linux/macOS):
   ```bash
   cd <path to project root>
   ./scripts/download_logo.sh "https://example.com/path/to/logo.png"
   ```

Build and run the app after placing the logo: `./gradlew assembleDebug` or use Android Studio.

If `logo.png` is not present, the app already falls back to `ic_launcher_foreground` vector drawable (or `logo.xml` if present) to avoid runtime crashes.
