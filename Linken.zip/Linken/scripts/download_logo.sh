#!/usr/bin/env bash
set -euo pipefail
if [ -z "${1:-}" ]; then
  echo "Usage: $0 <image-url>"
  exit 1
fi
URL="$1"
DST="app/src/main/res/drawable/logo.png"
mkdir -p "$(dirname "$DST")"
curl -L "$URL" -o "$DST"
echo "Saved to $DST"
echo "You can now rebuild the project to include the logo."