package com.weakglow.linken.service
import kotlin.random.Random

import com.weakglow.linken.data.ExternalEvent
import kotlinx.coroutines.delay
import java.util.*
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONArray
import android.content.Context

class EventDiscoveryService(private val context: Context? = null) {
    
    private val eventbriteApiKey: String? = com.weakglow.linken.BuildConfig.EVENTBRITE_PRIVATE_TOKEN.takeIf { it.isNotBlank() }
    private val ticketmasterApiKey: String? = com.weakglow.linken.BuildConfig.TICKETMASTER_API_KEY.takeIf { it.isNotBlank() }
    private val meetupApiKey: String? = com.weakglow.linken.BuildConfig.MEETUP_API_KEY.takeIf { it.isNotBlank() }
    private val bandsintownAppId: String? = (com.weakglow.linken.BuildConfig.BANDSINTOWN_APP_ID.takeIf { it.isNotBlank() } ?: "LinkEvents")
    private val facebookAccessToken: String? = com.weakglow.linken.BuildConfig.FACEBOOK_ACCESS_TOKEN.takeIf { it.isNotBlank() }
    private val trustedOrganizerIds: List<String> = com.weakglow.linken.BuildConfig.TRUSTED_EVENTBRITE_ORGANIZER_IDS
        .split(",").map { it.trim() }.filter { it.isNotEmpty() }
    private val trustedOrganizerNames: List<String> = com.weakglow.linken.BuildConfig.TRUSTED_EVENTBRITE_ORGANIZER_NAMES
        .split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
    private val forcedEventbriteUrls: List<String> = com.weakglow.linken.BuildConfig.FORCED_EVENTBRITE_URLS
        .split(",").map { it.trim() }.filter { it.isNotEmpty() }
    private val targetFacebookGroupUrls: List<String> = com.weakglow.linken.BuildConfig.TARGET_FACEBOOK_GROUP_URLS
        .split(",").map { it.trim() }.filter { it.isNotEmpty() }

    private val dynamicTrustedIds = mutableSetOf<String>()
    private val dynamicTrustedNames = mutableSetOf<String>()
    private val prefs = context?.getSharedPreferences("trusted_organizers", Context.MODE_PRIVATE)

    init {
        loadDynamicTrusted()
    }
    
    fun updateDynamicTrusted(ids: Collection<String> = emptyList(), names: Collection<String> = emptyList()) {
        dynamicTrustedIds.addAll(ids.filter { it.isNotBlank() })
        dynamicTrustedNames.addAll(names.map { it.lowercase() }.filter { it.isNotBlank() })
        saveDynamicTrusted()
    }

    private fun updateDynamicTrustedFromEvents(events: List<ExternalEvent>) {
        events.forEach { e ->
            if (e.source == "Eventbrite" && e.status?.lowercase() == "live") {
                e.organizerId?.let { dynamicTrustedIds.add(it) }
                e.organizer?.let { dynamicTrustedNames.add(it.lowercase()) }
            }
        }
        saveDynamicTrusted()
    }

    private fun loadDynamicTrusted() {
        try {
            val ids = prefs?.getStringSet("ids", emptySet()) ?: emptySet()
            val names = prefs?.getStringSet("names", emptySet()) ?: emptySet()
            dynamicTrustedIds.addAll(ids)
            dynamicTrustedNames.addAll(names)
        } catch (_: Exception) {}
    }

    private fun saveDynamicTrusted() {
        try {
            prefs?.edit()?.apply {
                putStringSet("ids", dynamicTrustedIds)
                putStringSet("names", dynamicTrustedNames)
                apply()
            }
        } catch (_: Exception) {}
    }

    private fun isTrusted(event: ExternalEvent): Boolean {
        val byId = event.organizerId != null && (trustedOrganizerIds.contains(event.organizerId) || dynamicTrustedIds.contains(event.organizerId))
        val byName = event.organizer != null && (trustedOrganizerNames.contains(event.organizer!!.lowercase()) || dynamicTrustedNames.contains(event.organizer!!.lowercase()))
        return byId || byName
    }
    
    private fun validateEvent(event: ExternalEvent): Boolean {
        if (event.title.isBlank() || event.dateTime <= 0 || event.location == null || event.source.isBlank()) return false
        if (!listOf("Eventbrite", "Ticketmaster", "Meetup", "Local Events", "Facebook Events", "Concerts-Metal", "Bandsintown").contains(event.source)) return false
        if (event.source == "Eventbrite") {
            if (event.status?.lowercase() != "live") return false
            if (event.url.isNullOrBlank() || !event.url.contains("eventbrite.com")) return false
        }
        if (event.source == "Facebook Events") {
            if (event.url.isNullOrBlank() || !event.url.contains("facebook.com/events")) return false
        }
        if (event.source == "Concerts-Metal") {
            if (event.url.isNullOrBlank() || !event.url.contains("concerts-metal.com")) return false
        }
        return true
    }

    private fun isUrlReachable(url: String?): Boolean {
        return try {
            if (url.isNullOrBlank()) return false
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = true
            conn.requestMethod = "GET"
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            val code = conn.responseCode
            code in 200..399
        } catch (_: Exception) {
            false
        }
    }

    private fun resolveEventbriteUrlById(id: String, fallback: String?): String? {
        return try {
            if (eventbriteApiKey == null) return fallback
            val url = "https://www.eventbriteapi.com/v3/events/$id/"
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.setRequestProperty("Authorization", "Bearer $eventbriteApiKey")
            val code = conn.responseCode
            if (code == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val pageUrl = json.optString("url")
                if (pageUrl.isNullOrBlank()) fallback else pageUrl
            } else fallback
        } catch (_: Exception) {
            fallback
        }
    }
    
    /**
     * Finds the closest events to a given date/time.
     * Algorithm prioritizes:
     * 1. Events closest to the target date
     * 2. Events within a reasonable time window (default: 30 days)
     * 3. Popular/relevant events from trusted sources
     * 
     * @param targetDate The date to find events near
     * @param daysRange Number of days before/after to search (default: 30)
     * @param maxResults Maximum number of results to return (default: 20)
     * @return List of external events sorted by proximity to target date
     */
    suspend fun findClosestEvents(
        targetDate: Long,
        daysRange: Int = 30,
        maxResults: Int = 20
    ): List<ExternalEvent> {
        // Simulate network delay
        delay(500)
        
        // Get events from all trusted sources
        val allEvents = fetchEventsFromTrustedSources(targetDate, daysRange)
        
        // Apply algorithm to find closest events
        return findClosestEventsAlgorithm(allEvents, targetDate, maxResults)
    }
    
    /**
     * Core algorithm to find closest events.
     * Uses a scoring system based on:
     * - Date proximity (closer events score higher)
     * - Source reliability (trusted sources score higher)
     * - Event popularity (if available)
     */
    private fun findClosestEventsAlgorithm(
        events: List<ExternalEvent>,
        targetDate: Long,
        maxResults: Int
    ): List<ExternalEvent> {
        val targetCalendar = Calendar.getInstance().apply {
            timeInMillis = targetDate
        }
        
        // Score each event
        val scoredEvents = events.map { event ->
            val eventCalendar = Calendar.getInstance().apply {
                timeInMillis = event.dateTime
            }
            
            // Calculate date difference in days
            val daysDifference = Math.abs(
                (event.dateTime - targetDate) / (1000 * 60 * 60 * 24)
            )
            
            // Score based on date proximity (lower days = higher score)
            val dateScore = when {
                daysDifference == 0L -> 100.0 // Exact match
                daysDifference <= 1 -> 90.0 - (daysDifference * 5) // Within 1 day
                daysDifference <= 7 -> 80.0 - (daysDifference * 2) // Within a week
                daysDifference <= 30 -> 60.0 - (daysDifference * 0.5) // Within a month
                else -> 20.0 - (daysDifference * 0.1) // Beyond a month
            }
            
            // Source reliability score (trusted sources get bonus)
            val sourceScore = when (event.source.lowercase()) {
                "eventbrite" -> 10.0
                "ticketmaster" -> 10.0
                "meetup" -> 8.0
                "local events" -> 7.0
                "facebook events" -> 6.0
                else -> 5.0
            }
            
            // Prefer future events over past events
            val futureBonus = if (event.dateTime >= targetDate) 5.0 else 0.0
            
            // Total score
            val totalScore = dateScore + sourceScore + futureBonus
            
            Pair(event, totalScore)
        }
        
        // Sort by score (highest first) and return top results
        return scoredEvents
            .sortedByDescending { it.second }
            .take(maxResults)
            .map { it.first }
    }
    
    /**
     * Fetches events from trusted sources using real APIs.
     * Currently uses Eventbrite and Ticketmaster APIs when keys are available.
     * Falls back to validated sample events for demonstration.
     */
    private suspend fun fetchEventsFromTrustedSources(
        targetDate: Long,
        daysRange: Int
    ): List<ExternalEvent> = withContext(Dispatchers.IO) {
        val events = mutableListOf<ExternalEvent>()
        
        // Try to fetch from Eventbrite API
        if (eventbriteApiKey != null) {
            try {
                if (forcedEventbriteUrls.isNotEmpty()) {
                    val forced = fetchEventbriteEventsFromUrls(forcedEventbriteUrls)
                    events.addAll(forced.filter { validateEvent(it) })
                    updateDynamicTrustedFromEvents(forced)
                }
                if (trustedOrganizerIds.isNotEmpty() || trustedOrganizerNames.isNotEmpty()) {
                    val organizerEvents = fetchEventbriteEventsByOrganizers()
                    events.addAll(organizerEvents.filter { validateEvent(it) && isTrusted(it) })
                    updateDynamicTrustedFromEvents(organizerEvents)
                }
                val cityEvents = fetchEventbriteEventsByCities()
                events.addAll(cityEvents.filter { validateEvent(it) && (trustedOrganizerIds.isEmpty() && trustedOrganizerNames.isEmpty() || isTrusted(it)) })
                updateDynamicTrustedFromEvents(cityEvents)
                val eventbriteEvents = fetchEventbriteEvents(targetDate, daysRange)
                events.addAll(eventbriteEvents.filter { validateEvent(it) && (trustedOrganizerIds.isEmpty() && trustedOrganizerNames.isEmpty() || isTrusted(it)) })
                updateDynamicTrustedFromEvents(eventbriteEvents)
            } catch (e: Exception) {
                // Log error but continue with other sources
                e.printStackTrace()
            }
        }
        
        // Try to fetch from Facebook Graph API
        if (facebookAccessToken != null) {
            try {
                val facebookEvents = fetchFacebookEvents(targetDate, daysRange)
                events.addAll(facebookEvents.filter { validateEvent(it) })
                if (targetFacebookGroupUrls.isNotEmpty()) {
                    for (g in targetFacebookGroupUrls) {
                        val groupEvents = fetchFacebookEventsFromGroup(g, targetDate, daysRange)
                        events.addAll(groupEvents.filter { validateEvent(it) })
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Try to fetch from Ticketmaster API
        if (ticketmasterApiKey != null) {
            try {
                val ticketmasterEvents = fetchTicketmasterEvents(targetDate, daysRange)
                events.addAll(ticketmasterEvents.filter { validateEvent(it) })
            } catch (e: Exception) {
                // Log error but continue with other sources
                e.printStackTrace()
            }
        }

        // Try to fetch from Bandsintown API (Lithuania only)
        if (bandsintownAppId != null) {
            try {
                val bandsintownEvents = fetchBandsintownEvents(targetDate, daysRange)
                events.addAll(bandsintownEvents.filter { validateEvent(it) })
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Try to fetch from Meetup API
        if (meetupApiKey != null) {
            try {
                val meetupEvents = fetchMeetupEvents(targetDate, daysRange)
                events.addAll(meetupEvents.filter { validateEvent(it) })
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        try {
            val hardcore = fetchVilniusHardcoreEvents(targetDate, daysRange)
            events.addAll(hardcore.filter { validateEvent(it) })
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            val concertsMetal = fetchConcertsMetalLithuaniaEvents(targetDate, daysRange)
            events.addAll(concertsMetal.filter { validateEvent(it) })
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        // If no events found from any source, provide demo events
        if (events.isEmpty()) {
            events.addAll(generateDemoEvents(targetDate, daysRange))
        }
        
        return@withContext events
    }
    
    /**
     * Fetches real events from Eventbrite API
     */
    private suspend fun fetchEventbriteEvents(
        targetDate: Long,
        daysRange: Int
    ): List<ExternalEvent> {
        val startDate = Calendar.getInstance().apply {
            timeInMillis = targetDate
            add(Calendar.DAY_OF_YEAR, -daysRange)
        }
        val endDate = Calendar.getInstance().apply {
            timeInMillis = targetDate
            add(Calendar.DAY_OF_YEAR, daysRange)
        }

        val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }

        val url = "https://www.eventbriteapi.com/v3/events/search/?" +
                "start_date.range_start=${dateFormat.format(startDate.time)}&" +
                "start_date.range_end=${dateFormat.format(endDate.time)}&" +
                "expand=venue,category,logo,organizer,ticket_availability"

        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("Authorization", "Bearer $eventbriteApiKey")

        val responseCode = connection.responseCode
        if (responseCode == 200) {
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(response)
            val eventsArray = json.optJSONArray("events")

            val events = mutableListOf<ExternalEvent>()
            if (eventsArray != null) {
                for (i in 0 until eventsArray.length()) {
                    val e = eventsArray.getJSONObject(i)
                    val id = e.optString("id")
                    val nameObj = e.optJSONObject("name")
                    val title = nameObj?.optString("text") ?: ""
                    val descObj = e.optJSONObject("description")
                    val description = descObj?.optString("text") ?: ""
                    val startObj = e.optJSONObject("start")
                    val startUtc = startObj?.optString("utc")
                    val dateTime = startUtc?.let {
                        try { dateFormat.parse(it)?.time ?: 0L } catch (_: Exception) { 0L }
                    } ?: 0L
                    val urlStr = e.optString("url")
                    val isFree = e.optBoolean("is_free")
                    val categoryObj = e.optJSONObject("category")
                    val categoryName = categoryObj?.optString("name") ?: "General"
                    val logoObj = e.optJSONObject("logo")
                    val imageUrl = logoObj?.optString("url")

                    val venueObj = e.optJSONObject("venue")
                    val venueName = venueObj?.optString("name")
                    val addressObj = venueObj?.optJSONObject("address")
                    val city = addressObj?.optString("city")
                    val country = addressObj?.optString("country")
                    val street = addressObj?.optString("address_1")
                    val postalCode = addressObj?.optString("postal_code")
                    val venueLat = venueObj?.optString("latitude")?.toDoubleOrNull()
                    val venueLng = venueObj?.optString("longitude")?.toDoubleOrNull()
                    val locationStr = listOfNotNull(country, city, venueName).joinToString(", ")
                    val organizerObj = e.optJSONObject("organizer")
                    val organizerName = organizerObj?.optString("name")
                    val organizerId = e.optString("organizer_id")
                    val status = e.optString("status")
                    val startTz = startObj?.optString("timezone")
                    val ticketAvail = e.optJSONObject("ticket_availability")
                    val minPrice = ticketAvail?.optJSONObject("minimum_ticket_price")?.optString("display")
                    val maxPrice = ticketAvail?.optJSONObject("maximum_ticket_price")?.optString("display")

                    val resolvedUrl = resolveEventbriteUrlById(id, urlStr)
                    if (status.equals("live", true) && !resolvedUrl.isNullOrBlank() && resolvedUrl.contains("eventbrite.com") && isUrlReachable(resolvedUrl)) {
                    events.add(
                        ExternalEvent(
                            id = id,
                            title = title,
                            description = description,
                            dateTime = dateTime,
                            location = if (locationStr.isNotBlank()) locationStr else venueName,
                            latitude = venueLat,
                            longitude = venueLng,
                            category = categoryName,
                            source = "Eventbrite",
                            url = resolvedUrl,
                            imageUrl = imageUrl,
                            price = if (isFree) "Free" else null,
                            venueName = venueName,
                            country = country,
                            city = city,
                            street = street,
                            postalCode = postalCode,
                            organizer = organizerName,
                            organizerId = organizerId,
                            status = status,
                            timezone = startTz,
                            minPrice = minPrice,
                            maxPrice = maxPrice,
                            ticketsUrl = urlStr
                        )
                    )
                    }
                }
            }
            return events
        }

        return emptyList()
    }

    private suspend fun fetchEventbriteEventsByCities(): List<ExternalEvent> {
        val now = Calendar.getInstance()
        val end = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 365) }
        val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        val cities = listOf(
            "Vilnius", "Kaunas", "Klaipėda", "Šiauliai", "Panevėžys",
            "Palanga", "Druskininkai", "Trakai", "Alytus", "Utena",
            "Marijampolė", "Tauragė", "Telšiai", "Jonava", "Mažeikiai",
            "Kėdainiai", "Šilutė"
        )
        val results = mutableListOf<ExternalEvent>()
        val seen = mutableSetOf<String>()

        for (city in cities) {
            val url = "https://www.eventbriteapi.com/v3/events/search/?" +
                    "expand=venue,category,logo,organizer,ticket_availability&" +
                    "location.address=${java.net.URLEncoder.encode(city, "UTF-8")}&" +
                    "start_date.range_start=${dateFormat.format(now.time)}&" +
                    "start_date.range_end=${dateFormat.format(end.time)}"

            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.setRequestProperty("Authorization", "Bearer $eventbriteApiKey")

            val responseCode = connection.responseCode
            if (responseCode == 200) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val eventsArray = json.optJSONArray("events")
                if (eventsArray != null) {
                    for (i in 0 until eventsArray.length()) {
                        val e = eventsArray.getJSONObject(i)
                        val id = e.optString("id")
                        if (id.isNotBlank() && seen.add(id)) {
                            val nameObj = e.optJSONObject("name")
                            val title = nameObj?.optString("text") ?: ""
                            val descObj = e.optJSONObject("description")
                            val description = descObj?.optString("text") ?: ""
                            val startObj = e.optJSONObject("start")
                            val startUtc = startObj?.optString("utc")
                            val dateTime = startUtc?.let {
                                try { dateFormat.parse(it)?.time ?: 0L } catch (_: Exception) { 0L }
                            } ?: 0L
                            val urlStr = e.optString("url")
                            val isFree = e.optBoolean("is_free")
                            val categoryObj = e.optJSONObject("category")
                            val categoryName = categoryObj?.optString("name") ?: "General"
                            val venueObj = e.optJSONObject("venue")
                            val venueName = venueObj?.optString("name")
                            val addressObj = venueObj?.optJSONObject("address")
                            val cityName = addressObj?.optString("city")
                            val country = addressObj?.optString("country")
                            val street = addressObj?.optString("address_1")
                            val postalCode = addressObj?.optString("postal_code")
                            val venueLat = venueObj?.optString("latitude")?.toDoubleOrNull()
                            val venueLng = venueObj?.optString("longitude")?.toDoubleOrNull()
                            val logoObj = e.optJSONObject("logo")
                            val imageUrl = logoObj?.optString("url")
                            val locationStr = listOfNotNull(country, cityName, venueName).joinToString(", ")
                            val organizerObj = e.optJSONObject("organizer")
                            val organizerName = organizerObj?.optString("name")
                            val status = e.optString("status")
                            val startTz = startObj?.optString("timezone")
                            val ticketAvail = e.optJSONObject("ticket_availability")
                            val minPrice = ticketAvail?.optJSONObject("minimum_ticket_price")?.optString("display")
                            val maxPrice = ticketAvail?.optJSONObject("maximum_ticket_price")?.optString("display")

                            val resolvedUrl = resolveEventbriteUrlById(id, urlStr)
                            if (status.equals("live", true) && !resolvedUrl.isNullOrBlank() && resolvedUrl.contains("eventbrite.com") && isUrlReachable(resolvedUrl)) {
                            results.add(
                                ExternalEvent(
                                    id = id,
                                    title = title,
                                    description = description,
                                    dateTime = dateTime,
                                    location = if (locationStr.isNotBlank()) locationStr else venueName,
                                    latitude = venueLat,
                                    longitude = venueLng,
                                    category = categoryName,
                                    source = "Eventbrite",
                                    url = resolvedUrl,
                                    imageUrl = imageUrl,
                                    price = if (isFree) "Free" else null,
                                    venueName = venueName,
                                    country = country,
                                    city = cityName,
                                    street = street,
                                    postalCode = postalCode,
                                    organizer = organizerName,
                                    status = status,
                                    timezone = startTz,
                                    minPrice = minPrice,
                                    maxPrice = maxPrice,
                                    ticketsUrl = urlStr
                            )
                            )
                            }
                        }
                    }
                }
            }
        }

        return results
    }

    private suspend fun fetchEventbriteEventsByOrganizers(): List<ExternalEvent> {
        val results = mutableListOf<ExternalEvent>()
        val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        for (orgId in trustedOrganizerIds) {
            val url = "https://www.eventbriteapi.com/v3/organizers/$orgId/events/?expand=venue,category,logo,organizer,ticket_availability"
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.setRequestProperty("Authorization", "Bearer $eventbriteApiKey")
            val responseCode = connection.responseCode
            if (responseCode == 200) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val eventsArray = json.optJSONArray("events") ?: json.optJSONArray("data")
                if (eventsArray != null) {
                    for (i in 0 until eventsArray.length()) {
                        val e = eventsArray.getJSONObject(i)
                        val id = e.optString("id")
                        val nameObj = e.optJSONObject("name")
                        val title = nameObj?.optString("text") ?: ""
                        val descObj = e.optJSONObject("description")
                        val description = descObj?.optString("text") ?: ""
                        val startObj = e.optJSONObject("start")
                        val startUtc = startObj?.optString("utc")
                        val dateTime = startUtc?.let { try { dateFormat.parse(it)?.time ?: 0L } catch (_: Exception) { 0L } } ?: 0L
                        val urlStr = e.optString("url")
                        val isFree = e.optBoolean("is_free")
                        val categoryObj = e.optJSONObject("category")
                        val categoryName = categoryObj?.optString("name") ?: "General"
                        val logoObj = e.optJSONObject("logo")
                        val imageUrl = logoObj?.optString("url")
                        val venueObj = e.optJSONObject("venue")
                        val venueName = venueObj?.optString("name")
                        val addressObj = venueObj?.optJSONObject("address")
                        val city = addressObj?.optString("city")
                        val country = addressObj?.optString("country")
                        val street = addressObj?.optString("address_1")
                        val postalCode = addressObj?.optString("postal_code")
                        val venueLat = venueObj?.optString("latitude")?.toDoubleOrNull()
                        val venueLng = venueObj?.optString("longitude")?.toDoubleOrNull()
                        val organizerObj = e.optJSONObject("organizer")
                        val organizerName = organizerObj?.optString("name")
                        val organizerId = e.optString("organizer_id")
                        val status = e.optString("status")
                        val startTz = startObj?.optString("timezone")
                        val ticketAvail = e.optJSONObject("ticket_availability")
                        val minPrice = ticketAvail?.optJSONObject("minimum_ticket_price")?.optString("display")
                        val maxPrice = ticketAvail?.optJSONObject("maximum_ticket_price")?.optString("display")
                        val locationStr = listOfNotNull(country, city, venueName).joinToString(", ")
                        val resolvedUrl = resolveEventbriteUrlById(id, urlStr)
                        if (status.equals("live", true) && !resolvedUrl.isNullOrBlank() && resolvedUrl.contains("eventbrite.com") && isUrlReachable(resolvedUrl)) {
                        results.add(
                            ExternalEvent(
                                id = id,
                                title = title,
                                description = description,
                                dateTime = dateTime,
                                location = if (locationStr.isNotBlank()) locationStr else venueName,
                                latitude = venueLat,
                                longitude = venueLng,
                                category = categoryName,
                                source = "Eventbrite",
                                url = resolvedUrl,
                                imageUrl = imageUrl,
                                price = if (isFree) "Free" else null,
                                venueName = venueName,
                                country = country,
                                city = city,
                                street = street,
                                postalCode = postalCode,
                                organizer = organizerName,
                                organizerId = organizerId,
                                status = status,
                                timezone = startTz,
                                minPrice = minPrice,
                                maxPrice = maxPrice,
                                ticketsUrl = urlStr
                        )
                        )
                        }
                    }
                }
            }
        }
        return results
    }

    /**
     * Fetches events from Facebook Graph API using search queries.
     * Requires a valid app/user access token with permissions.
     */
    private suspend fun fetchFacebookEvents(
        targetDate: Long,
        daysRange: Int
    ): List<ExternalEvent> {
        val startDate = Calendar.getInstance().apply {
            timeInMillis = targetDate
            add(Calendar.DAY_OF_YEAR, -daysRange)
        }
        val endDate = Calendar.getInstance().apply {
            timeInMillis = targetDate
            add(Calendar.DAY_OF_YEAR, daysRange)
        }
        val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }

        val queries = listOf("concert", "festival", "meetup", "workshop")
        val events = mutableListOf<ExternalEvent>()

        for (q in queries) {
            val url = "https://graph.facebook.com/v19.0/search?" +
                    "type=event&" +
                    "q=${q}&" +
                    "fields=name,description,start_time,place,cover&" +
                    "since=${dateFormat.format(startDate.time)}&" +
                    "until=${dateFormat.format(endDate.time)}&" +
                    "access_token=$facebookAccessToken"

            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"

            val responseCode = connection.responseCode
            if (responseCode == 200) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val data = json.optJSONArray("data")
                if (data != null) {
                    for (i in 0 until data.length()) {
                        val e = data.getJSONObject(i)
                        val id = e.optString("id")
                        val title = e.optString("name")
                        val description = e.optString("description")
                        val start = e.optString("start_time")
                        val dateTime = start?.let {
                            try { dateFormat.parse(it)?.time ?: 0L } catch (_: Exception) { 0L }
                        } ?: 0L
                        val place = e.optJSONObject("place")
                        val placeName = place?.optString("name")
                        val loc = place?.optJSONObject("location")
                        val city = loc?.optString("city")
                        val country = loc?.optString("country")
                        val street = loc?.optString("street")
                        val lat = loc?.optDouble("latitude")
                        val lng = loc?.optDouble("longitude")
                        val cover = e.optJSONObject("cover")
                        val coverUrl = cover?.optString("source")
                        val locationStr = listOfNotNull(country, city, placeName).joinToString(", ")

                        events.add(
                            ExternalEvent(
                                id = id,
                                title = title ?: "",
                                description = description ?: "",
                                dateTime = dateTime,
                                location = if (locationStr.isNotBlank()) locationStr else placeName,
                                latitude = lat,
                                longitude = lng,
                                category = "General",
                                source = "Facebook Events",
                                url = "https://www.facebook.com/events/$id",
                                imageUrl = coverUrl,
                                price = null,
                                venueName = placeName,
                                country = country,
                                city = city,
                                street = street,
                                ticketsUrl = "https://www.facebook.com/events/$id"
                            )
                        )
                    }
                }
            }
        }

        return events
    }
    
    /**
     * Fetches real events from Ticketmaster API
     */
    private suspend fun fetchTicketmasterEvents(
        targetDate: Long,
        daysRange: Int
    ): List<ExternalEvent> {
        val startDate = Calendar.getInstance().apply {
            timeInMillis = targetDate
            add(Calendar.DAY_OF_YEAR, -daysRange)
        }
        val endDate = Calendar.getInstance().apply {
            timeInMillis = targetDate
            add(Calendar.DAY_OF_YEAR, daysRange)
        }
        
        val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        dateFormat.timeZone = java.util.TimeZone.getTimeZone("UTC")
        
        val url = "https://app.ticketmaster.com/discovery/v2/events.json?" +
                "apikey=$ticketmasterApiKey&" +
                "startDateTime=${dateFormat.format(startDate.time)}&" +
                "endDateTime=${dateFormat.format(endDate.time)}&" +
                "size=50"
        
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        
        val responseCode = connection.responseCode
        if (responseCode == 200) {
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(response)
            val embedded = json.optJSONObject("_embedded")
            
            val events = mutableListOf<ExternalEvent>()
            if (embedded != null) {
                val eventsArray = embedded.optJSONArray("events")
                if (eventsArray != null) {
                    for (i in 0 until eventsArray.length()) {
                        val e = eventsArray.optJSONObject(i) ?: continue
                        val id = e.optString("id")
                        val title = e.optString("name")
                        val dates = e.optJSONObject("dates")
                        val start = dates?.optJSONObject("start")
                        val startIso = start?.optString("dateTime")
                        val dateMs = try {
                            java.time.OffsetDateTime.parse(startIso).toInstant().toEpochMilli()
                        } catch (_: Exception) {
                            try { java.time.Instant.parse(startIso).toEpochMilli() } catch (_: Exception) {
                                try { dateFormat.parse(startIso)?.time ?: 0L } catch (_: Exception) { 0L }
                            }
                        }
                        val urlStr = e.optString("url")
                        val images = e.optJSONArray("images")
                        val imageUrl = images?.optJSONObject(0)?.optString("url")
                        val embeddedEvent = e.optJSONObject("_embedded")
                        val venuesArray = embeddedEvent?.optJSONArray("venues")
                        val venueObj = venuesArray?.optJSONObject(0)
                        val venueName = venueObj?.optString("name")
                        val cityObj = venueObj?.optJSONObject("city")
                        val countryObj = venueObj?.optJSONObject("country")
                        val addressObj = venueObj?.optJSONObject("address")
                        val postalCode = venueObj?.optString("postalCode")
                        val locObj = venueObj?.optJSONObject("location")
                        val lat = locObj?.optString("latitude")?.toDoubleOrNull()
                        val lng = locObj?.optString("longitude")?.toDoubleOrNull()
                        val locationStr = listOfNotNull(countryObj?.optString("name"), cityObj?.optString("name"), venueName).joinToString(", ")
                        val classifications = e.optJSONArray("classifications")
                        val seg = classifications?.optJSONObject(0)?.optJSONObject("segment")?.optString("name")
                        val genreName = classifications?.optJSONObject(0)?.optJSONObject("genre")?.optString("name")
                        val cat = listOfNotNull(seg, genreName).firstOrNull() ?: "Concerts"
                        if (!title.isNullOrBlank() && dateMs > 0) {
                            events.add(
                                ExternalEvent(
                                    id = id,
                                    title = title,
                                    description = "",
                                    dateTime = dateMs,
                                    location = if (locationStr.isNotBlank()) locationStr else venueName,
                                    latitude = lat,
                                    longitude = lng,
                                    category = cat,
                                    source = "Ticketmaster",
                                    url = urlStr,
                                    imageUrl = imageUrl,
                                    price = null,
                                    venueName = venueName,
                                    country = countryObj?.optString("name"),
                                    city = cityObj?.optString("name"),
                                    street = addressObj?.optString("line1"),
                                    postalCode = postalCode,
                                    ticketsUrl = urlStr
                                )
                            )
                        }
                    }
                }
            }
            return events
        }
        
        return emptyList()
    }

    /**
     * Fetches upcoming concerts from Bandsintown for Lithuania only.
     * Uses geo coordinates of major cities and filters venues in LT.
     */
    private suspend fun fetchBandsintownEvents(
        targetDate: Long,
        daysRange: Int
    ): List<ExternalEvent> {
        if (bandsintownAppId == null) return emptyList()
        val cities = listOf(
            Triple("Vilnius", 54.6872, 25.2797),
            Triple("Kaunas", 54.8985, 23.9036),
            Triple("Klaipėda", 55.7033, 21.1443),
            Triple("Šiauliai", 55.9333, 23.3167),
            Triple("Panevėžys", 55.7333, 24.35),
            Triple("Alytus", 54.4012, 24.0491),
            Triple("Trakai", 54.6371, 24.9340),
            Triple("Palanga", 55.9183, 21.0686)
        )
        val events = mutableListOf<ExternalEvent>()
        for ((cityName, lat, lng) in cities) {
            val url = "https://rest.bandsintown.com/events?app_id=${bandsintownAppId}&date=upcoming&geo=${lat},${lng}&radius=100"
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                val responseCode = connection.responseCode
                if (responseCode == 200) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    val arr = try { JSONArray(response) } catch (_: Exception) { null }
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val e = arr.optJSONObject(i) ?: continue
                            val id = e.optString("id")
                            val datetime = e.optString("datetime")
                            val dateMs = try { java.time.OffsetDateTime.parse(datetime).toInstant().toEpochMilli() } catch (_: Exception) {
                                try { java.time.Instant.parse(datetime).toEpochMilli() } catch (_: Exception) { 0L }
                            }
                            val venue = e.optJSONObject("venue")
                            val venueName = venue?.optString("name")
                            val vcity = venue?.optString("city")
                            val vcountry = venue?.optString("country")
                            val vlat = venue?.optDouble("latitude")
                            val vlng = venue?.optDouble("longitude")
                            val lineup = e.optJSONArray("artists")
                            val firstArtist = lineup?.optJSONObject(0)?.optString("name")
                            val urlStr = e.optString("url")
                            // Only Lithuania
                            val countryOk = vcountry?.equals("LT", true) == true || vcountry?.equals("Lithuania", true) == true
                            if (countryOk && !firstArtist.isNullOrBlank() && dateMs > 0) {
                                events.add(
                                    ExternalEvent(
                                        id = id,
                                        title = firstArtist,
                                        description = "",
                                        dateTime = dateMs,
                                        location = listOfNotNull(vcountry, vcity, venueName).joinToString(", "),
                                        latitude = vlat,
                                        longitude = vlng,
                                        category = "Concerts",
                                        source = "Bandsintown",
                                        url = urlStr,
                                        imageUrl = null,
                                        price = null,
                                        venueName = venueName,
                                        country = vcountry,
                                        city = vcity,
                                        ticketsUrl = urlStr
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                // ignore and proceed to next city
            }
        }
        return events
    }

    private suspend fun fetchMeetupEvents(
        targetDate: Long,
        daysRange: Int
    ): List<ExternalEvent> {
        if (meetupApiKey == null) return emptyList()
        val url = "https://api.meetup.com/find/upcoming_events?key=$meetupApiKey&page=50"
        return try {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            val responseCode = connection.responseCode
            if (responseCode == 200) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val eventsArray = json.optJSONArray("events")
                val events = mutableListOf<ExternalEvent>()
                if (eventsArray != null) {
                    for (i in 0 until eventsArray.length()) {
                        val e = eventsArray.optJSONObject(i) ?: continue
                        val id = e.optString("id")
                        val title = e.optString("name")
                        val timeMs = e.optLong("time")
                        val venue = e.optJSONObject("venue")
                        val venueName = venue?.optString("name")
                        val city = venue?.optString("city")
                        val country = venue?.optString("country")
                        val lat = venue?.optDouble("lat")
                        val lon = venue?.optDouble("lon")
                        val link = e.optString("link")
                        if (!title.isNullOrBlank() && timeMs > 0) {
                            events.add(
                                ExternalEvent(
                                    id = id,
                                    title = title,
                                    description = "",
                                    dateTime = timeMs,
                                    location = listOfNotNull(country, city, venueName).joinToString(", "),
                                    latitude = lat,
                                    longitude = lon,
                                    category = "Meetings",
                                    source = "Meetup",
                                    url = link,
                                    imageUrl = null,
                                    price = null,
                                    venueName = venueName,
                                    country = country,
                                    city = city,
                                    ticketsUrl = link
                                )
                            )
                        }
                    }
                }
                events
            } else emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }
    
    private fun extractEventbriteId(url: String): String? {
        val regex = Regex("-([0-9]{10,})")
        val match = regex.find(url)
        return match?.groupValues?.get(1)
    }

    private suspend fun fetchEventbriteEventsFromUrls(urls: List<String>): List<ExternalEvent> {
        val out = mutableListOf<ExternalEvent>()
        for (u in urls) {
            val id = extractEventbriteId(u) ?: continue
            val ev = fetchEventbriteEventById(id)
            if (ev != null) out.add(ev)
        }
        return out
    }

    private suspend fun fetchEventbriteEventById(id: String): ExternalEvent? {
        val url = "https://www.eventbriteapi.com/v3/events/$id/?expand=venue,category,logo,organizer,ticket_availability"
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("Authorization", "Bearer $eventbriteApiKey")
        val responseCode = connection.responseCode
        if (responseCode == 200) {
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            val e = JSONObject(response)
            val nameObj = e.optJSONObject("name")
            val title = nameObj?.optString("text") ?: ""
            val descObj = e.optJSONObject("description")
            val description = descObj?.optString("text") ?: ""
            val startObj = e.optJSONObject("start")
            val startUtc = startObj?.optString("utc")
            val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }
            val dateTime = startUtc?.let { try { dateFormat.parse(it)?.time ?: 0L } catch (_: Exception) { 0L } } ?: 0L
            val urlStr = e.optString("url")
            val isFree = e.optBoolean("is_free")
            val categoryObj = e.optJSONObject("category")
            val categoryName = categoryObj?.optString("name") ?: "General"
            val logoObj = e.optJSONObject("logo")
            val imageUrl = logoObj?.optString("url")
            val venueObj = e.optJSONObject("venue")
            val venueName = venueObj?.optString("name")
            val addressObj = venueObj?.optJSONObject("address")
            val city = addressObj?.optString("city")
            val country = addressObj?.optString("country")
            val street = addressObj?.optString("address_1")
            val postalCode = addressObj?.optString("postal_code")
            val venueLat = venueObj?.optString("latitude")?.toDoubleOrNull()
            val venueLng = venueObj?.optString("longitude")?.toDoubleOrNull()
            val organizerObj = e.optJSONObject("organizer")
            val organizerName = organizerObj?.optString("name")
            val organizerId = e.optString("organizer_id")
            val status = e.optString("status")
            val startTz = startObj?.optString("timezone")
            val ticketAvail = e.optJSONObject("ticket_availability")
            val minPrice = ticketAvail?.optJSONObject("minimum_ticket_price")?.optString("display")
            val maxPrice = ticketAvail?.optJSONObject("maximum_ticket_price")?.optString("display")
            val locationStr = listOfNotNull(country, city, venueName).joinToString(", ")
            val resolvedUrl = resolveEventbriteUrlById(id, urlStr)
            if (status.equals("live", true) && !resolvedUrl.isNullOrBlank() && resolvedUrl.contains("eventbrite.com") && isUrlReachable(resolvedUrl)) {
                return ExternalEvent(
                    id = id,
                    title = title,
                    description = description,
                    dateTime = dateTime,
                    location = if (locationStr.isNotBlank()) locationStr else venueName,
                    latitude = venueLat,
                    longitude = venueLng,
                    category = categoryName,
                    source = "Eventbrite",
                    url = resolvedUrl,
                    imageUrl = imageUrl,
                    price = if (isFree) "Free" else null,
                    venueName = venueName,
                    country = country,
                    city = city,
                    street = street,
                    postalCode = postalCode,
                    organizer = organizerName,
                    organizerId = organizerId,
                    status = status,
                    timezone = startTz,
                    minPrice = minPrice,
                    maxPrice = maxPrice,
                    ticketsUrl = resolvedUrl
                )
            }
        }
        return null
    }
    private suspend fun fetchVilniusHardcoreEvents(targetDate: Long, daysRange: Int): List<ExternalEvent> {
        val baseUrl = "https://vilnius.hardcore.lt/"
        val connection = URL(baseUrl).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        val code = connection.responseCode
        if (code != 200) return emptyList()
        val html = connection.inputStream.bufferedReader().use { it.readText() }

        val events = mutableListOf<ExternalEvent>()
        val upcomingSectionRegex = Regex("(?is)(upcoming events|artimiausi renginiai).*?<(/?section|/?div)")
        val hasUpcoming = upcomingSectionRegex.containsMatchIn(html)
        if (!hasUpcoming) return emptyList()

        val itemRegex = Regex("(?is)<a[^>]*href=\"([^\\\"]+)\"[^>]*>(.*?)</a>.*?(\\d{4}-\\d{2}-\\d{2}|\\d{2}\\.\\d{2}\\.\\d{4})")
        val matches = itemRegex.findAll(html).toList()
        val dateFormats = listOf(
            java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US),
            java.text.SimpleDateFormat("dd.MM.yyyy", Locale.US)
        )
        for (m in matches) {
            val href = m.groupValues.getOrNull(1) ?: continue
            val titleRaw = m.groupValues.getOrNull(2)?.replace(Regex("<[^>]+>"), "")?.trim() ?: continue
            val dateStr = m.groupValues.getOrNull(3)
            var dateMs = 0L
            if (!dateStr.isNullOrBlank()) {
                for (df in dateFormats) {
                    try {
                        dateMs = df.parse(dateStr)?.time ?: 0L
                        if (dateMs > 0) break
                    } catch (_: Exception) {}
                }
            }
            val absUrl = if (href.startsWith("http")) href else baseUrl.trimEnd('/') + "/" + href.trimStart('/')
            if (!isUrlReachable(absUrl)) continue
            val location = "Vilnius"
            if (titleRaw.isNotBlank() && dateMs > 0) {
                events.add(
                    ExternalEvent(
                        id = absUrl,
                        title = titleRaw,
                        description = "",
                        dateTime = dateMs,
                        location = location,
                        latitude = null,
                        longitude = null,
                        category = "Music",
                        source = "Vilnius Hardcore",
                        url = absUrl,
                        imageUrl = null,
                        price = null
                    )
                )
            }
        }
        return events
    }
    private fun extractFacebookEventIdFromUrl(url: String?): String? {
        if (url.isNullOrBlank()) return null
        val m = Regex("facebook\\.com/events/(\\d+)").find(url)
        return m?.groupValues?.get(1)
    }

    private fun resolveFacebookGroupId(slugOrId: String): String? {
        val s = slugOrId.trim().removePrefix("https://www.facebook.com/groups/").removeSuffix("/")
        if (s.matches(Regex("\\d+"))) return s
        val url = "https://graph.facebook.com/v19.0/$s?fields=id&access_token=$facebookAccessToken"
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            val code = conn.responseCode
            if (code == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                json.optString("id").takeIf { it.isNotBlank() }
            } else null
        } catch (_: Exception) {
            null
        }
    }

    private suspend fun fetchFacebookEventsFromGroup(groupSlugOrId: String, targetDate: Long, daysRange: Int): List<ExternalEvent> {
        val groupId = resolveFacebookGroupId(groupSlugOrId) ?: return emptyList()
        val url = "https://graph.facebook.com/v19.0/$groupId/feed?fields=message,created_time,permalink_url,attachments{url},link&limit=50&access_token=$facebookAccessToken"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        val code = conn.responseCode
        if (code != 200) return emptyList()
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(body)
        val data = json.optJSONArray("data") ?: return emptyList()
        val events = mutableListOf<ExternalEvent>()

        val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }

        for (i in 0 until data.length()) {
            val post = data.getJSONObject(i)
            val link = post.optString("link")
            val permalink = post.optString("permalink_url")
            var eventUrl: String? = null
            eventUrl = extractFacebookEventIdFromUrl(link)?.let { "https://www.facebook.com/events/$it" } ?: eventUrl
            eventUrl = eventUrl ?: extractFacebookEventIdFromUrl(permalink)?.let { "https://www.facebook.com/events/$it" }
            if (eventUrl == null) {
                val atts = post.optJSONObject("attachments")
                if (atts != null) {
                    val attData = atts.optJSONArray("data") ?: JSONArray()
                    for (j in 0 until attData.length()) {
                        val att = attData.optJSONObject(j)
                        val attUrl = att?.optString("url")
                        val id = extractFacebookEventIdFromUrl(attUrl)
                        if (id != null) { eventUrl = "https://www.facebook.com/events/$id"; break }
                    }
                }
            }
            val eventId = extractFacebookEventIdFromUrl(eventUrl)
            if (eventId != null) {
                val evUrl = "https://graph.facebook.com/v19.0/$eventId?fields=name,description,start_time,place,cover,is_canceled&access_token=$facebookAccessToken"
                try {
                    val econn = URL(evUrl).openConnection() as HttpURLConnection
                    econn.requestMethod = "GET"
                    val ec = econn.responseCode
                    if (ec == 200) {
                        val eresp = econn.inputStream.bufferedReader().use { it.readText() }
                        val ejson = JSONObject(eresp)
                        val title = ejson.optString("name")
                        val description = ejson.optString("description")
                        val start = ejson.optString("start_time")
                        val dateTime = start?.let { try { dateFormat.parse(it)?.time ?: 0L } catch (_: Exception) { 0L } } ?: 0L
                        val place = ejson.optJSONObject("place")
                        val placeName = place?.optString("name")
                        val loc = place?.optJSONObject("location")
                        val city = loc?.optString("city")
                        val country = loc?.optString("country")
                        val street = loc?.optString("street")
                        val lat = loc?.optDouble("latitude")
                        val lng = loc?.optDouble("longitude")
                        val cover = ejson.optJSONObject("cover")
                        val coverUrl = cover?.optString("source")
                        val locationStr = listOfNotNull(country, city, placeName).joinToString(", ")
                        val canceled = ejson.optBoolean("is_canceled")
                        if (!canceled) {
                            events.add(
                                ExternalEvent(
                                    id = eventId,
                                    title = title ?: "",
                                    description = description ?: "",
                                    dateTime = dateTime,
                                    location = if (locationStr.isNotBlank()) locationStr else placeName,
                                    latitude = lat,
                                    longitude = lng,
                                    category = "General",
                                    source = "Facebook Events",
                                    url = "https://www.facebook.com/events/$eventId",
                                    imageUrl = coverUrl,
                                    price = null,
                                    venueName = placeName,
                                    country = country,
                                    city = city,
                                    street = street,
                                    ticketsUrl = "https://www.facebook.com/events/$eventId"
                                )
                            )
                        }
                    }
                } catch (_: Exception) {}
            }
        }
        return events
    }
}
    private suspend fun fetchConcertsMetalLithuaniaEvents(targetDate: Long, daysRange: Int): List<ExternalEvent> {
        val base = "https://en.concerts-metal.com/LT__Lithuania"
        val conn = URL(base).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 5000
        conn.readTimeout = 7000
        val code = conn.responseCode
        if (code != 200) return emptyList()
        val html = conn.inputStream.bufferedReader().use { it.readText() }

        val links = mutableSetOf<String>()
        val linkRegex = Regex("(?is)<a[^>]+href=\"([^\"]+)\"[^>]*>")
        linkRegex.findAll(html).forEach { m ->
            val href = m.groupValues.getOrNull(1) ?: return@forEach
            val abs = if (href.startsWith("http")) href else "https://en.concerts-metal.com/" + href.trimStart('/')
            if (abs.contains("concerts-metal.com/")) {
                if (abs.contains("/dates/") || abs.contains("/concert") || abs.contains("/festival")) {
                    links.add(abs)
                }
            }
        }

        val events = mutableListOf<ExternalEvent>()
        val dateFormats = listOf(
            java.text.SimpleDateFormat("dd/MM/yyyy", Locale.US),
            java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US)
        )
        for (url in links.take(40)) {
            try {
                val econn = URL(url).openConnection() as HttpURLConnection
                econn.requestMethod = "GET"
                econn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) LinkEvents/1.0")
                econn.connectTimeout = 5000
                econn.readTimeout = 7000
                val ec = econn.responseCode
                if (ec != 200) continue
                val body = econn.inputStream.bufferedReader().use { it.readText() }
                if (body.contains("The access limit has been reached", ignoreCase = true)) {
                    continue
                }
                val title = Regex("(?is)<meta\\s+property=\\\"og:title\\\"\\s+content=\\\"([^\\\"]+)\\\"").find(body)?.groupValues?.get(1)
                    ?: Regex("(?is)<h1[^>]*>(.*?)</h1>").find(body)?.groupValues?.get(1)?.replace(Regex("<[^>]+>"), "")?.trim()
                val dateStr = Regex("(?is)(Date\\s*:?)\\s*(\\d{2}/\\d{2}/\\d{4})").find(body)?.groupValues?.get(2)
                    ?: Regex("(?is)(\\d{4}-\\d{2}-\\d{2})").find(body)?.groupValues?.get(1)
                var dateMs = 0L
                if (!dateStr.isNullOrBlank()) {
                    for (df in dateFormats) {
                        try { dateMs = df.parse(dateStr)?.time ?: 0L; if (dateMs > 0) break } catch (_: Exception) {}
                    }
                }
                val citySlug = Regex("(?is)/LT/([A-Za-z\\-]+)").find(body)?.groupValues?.get(1)
                val city = citySlug?.replace('-', ' ')
                val venue = Regex("(?is)(Venue|Place|Club)\\s*:?\\s*([A-Za-z0-9À-ÿ'&\\-\\s]+)").find(body)?.groupValues?.get(2)
                val country = "Lithuania"
                val locationStr = listOfNotNull(country, city, venue).joinToString(", ")

                if (!title.isNullOrBlank() && dateMs > System.currentTimeMillis()) {
                    events.add(
                        ExternalEvent(
                            id = url,
                            title = title.trim(),
                            description = "",
                            dateTime = dateMs,
                            location = if (locationStr.isNotBlank()) locationStr else city ?: country,
                            latitude = null,
                            longitude = null,
                            category = "Underground (metal)",
                            source = "Concerts-Metal",
                            url = url,
                            imageUrl = null,
                            price = null,
                            venueName = venue,
                            country = country,
                            city = city,
                            ticketsUrl = url
                        )
                    )
                }
            } catch (_: Exception) {}
        }
        return events
    }

    /**
     * Generates demo events for testing/demonstration when no API keys are available.
     */
    private fun generateDemoEvents(targetDate: Long, daysRange: Int): List<ExternalEvent> {
        val cal = Calendar.getInstance().apply { timeInMillis = targetDate }
        val demoEvents = mutableListOf<ExternalEvent>()
        
        // Demo event 1: Concert in Vilnius (3 days from now)
        cal.add(Calendar.DAY_OF_YEAR, 3)
        demoEvents.add(ExternalEvent(
            id = "demo_1",
            title = "Synthwave Night at Vilniaus Arena-Vilnius-Lithuania",
            description = "Electronic music festival featuring local and international artists",
            dateTime = cal.timeInMillis,
            location = "Vilnius, Lithuania",
            latitude = 54.6872,
            longitude = 25.2797,
            category = "Concerts",
            source = "Local Events",
            url = "https://example.com/event1",
            imageUrl = null,
            price = "€15",
            venueName = "Vilniaus Arena",
            country = "Lithuania",
            city = "Vilnius"
        ))
        
        // Demo event 2: Metal concert (5 days from now)
        cal.add(Calendar.DAY_OF_YEAR, 2)
        demoEvents.add(ExternalEvent(
            id = "demo_2",
            title = "Heavy Metal Night at Kaunas Club-Kaunas-Lithuania",
            description = "Live metal band performances",
            dateTime = cal.timeInMillis,
            location = "Kaunas, Lithuania",
            latitude = 54.9024,
            longitude = 24.0373,
            category = "Underground (metal)",
            source = "Local Events",
            url = "https://example.com/event2",
            imageUrl = null,
            price = null,
            venueName = "Kaunas Club",
            country = "Lithuania",
            city = "Kaunas"
        ))
        
        // Demo event 3: Festival (7 days from now)
        cal.add(Calendar.DAY_OF_YEAR, 2)
        demoEvents.add(ExternalEvent(
            id = "demo_3",
            title = "Summer Music Festival at Klaipėda Beach-Klaipėda-Lithuania",
            description = "Multi-genre music festival by the Baltic Sea",
            dateTime = cal.timeInMillis,
            location = "Klaipėda, Lithuania",
            latitude = 55.7206,
            longitude = 21.1445,
            category = "Concerts",
            source = "Local Events",
            url = "https://example.com/event3",
            imageUrl = null,
            price = "€25",
            venueName = "Klaipėda Beach",
            country = "Lithuania",
            city = "Klaipėda"
        ))
        
        // Demo event 4: Club night (10 days from now)
        cal.add(Calendar.DAY_OF_YEAR, 3)
        demoEvents.add(ExternalEvent(
            id = "demo_4",
            title = "Techno Saturday at Vilniaus Nightclub-Vilnius-Lithuania",
            description = "All night techno DJ set",
            dateTime = cal.timeInMillis,
            location = "Vilnius, Lithuania",
            latitude = 54.6872,
            longitude = 25.2797,
            category = "Clubs",
            source = "Local Events",
            url = "https://example.com/event4",
            imageUrl = null,
            price = "€10",
            venueName = "Vilniaus Nightclub",
            country = "Lithuania",
            city = "Vilnius"
        ))
        
        return demoEvents
    }

