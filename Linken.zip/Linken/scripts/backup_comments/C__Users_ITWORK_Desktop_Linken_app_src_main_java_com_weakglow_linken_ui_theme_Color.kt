package com.weakglow.linken.ui.theme

import androidx.compose.ui.graphics.Color

// Rich purple palette for dark theme
val Purple80 = Color(0xFFE1BEE7) // Light purple
val PurpleGrey80 = Color(0xFFCE93D8) // Medium purple
val Pink80 = Color(0xFFF8BBD0) // Soft pink-purple

// Rich purple palette for light theme
val Purple40 = Color(0xFF7B1FA2) // Deep purple
val PurpleGrey40 = Color(0xFF9C27B0) // Vibrant purple
val Pink40 = Color(0xFFBA68C8) // Purple-pink

// Additional purple accents
val PurpleAccent = Color(0xFFA027B6) // Material Purple 500
val PurpleLight = Color(0xFFE1BEE7) // Material Purple 100
val PurpleDark = Color(0xFF6A1B9A) // Material Purple 800
val PurpleVibrant = Color(0xFFAB47BC) // Material Purple 400