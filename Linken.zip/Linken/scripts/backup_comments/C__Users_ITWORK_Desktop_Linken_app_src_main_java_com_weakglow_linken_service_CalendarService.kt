package com.weakglow.linken.service

import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import android.net.Uri
import com.weakglow.linken.data.Event
import java.util.Calendar

/**
 * Service for adding events to the Android Calendar app.
 */
class CalendarService(private val context: Context) {
    
    /**
     * Adds an event to the default calendar.
     * Returns the calendar event ID if successful, null otherwise.
     */
    fun addEventToCalendar(event: Event): Long? {
        try {
            val calendar = Calendar.getInstance().apply {
                timeInMillis = event.dateTime
            }
            
            val startMillis = calendar.timeInMillis
            // Default event duration: 1 hour
            calendar.add(Calendar.HOUR_OF_DAY, 1)
            val endMillis = calendar.timeInMillis
            
            val values = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, startMillis)
                put(CalendarContract.Events.DTEND, endMillis)
                put(CalendarContract.Events.TITLE, event.title)
                put(CalendarContract.Events.DESCRIPTION, event.description)
                put(CalendarContract.Events.CALENDAR_ID, getDefaultCalendarId())
                put(CalendarContract.Events.EVENT_TIMEZONE, Calendar.getInstance().timeZone.id)
                
                // Add location if available
                event.location?.let {
                    put(CalendarContract.Events.EVENT_LOCATION, it)
                }
                
                // Add category as event color
                put(CalendarContract.Events.EVENT_COLOR, event.color.toInt())
            }
            
            val uri: Uri? = context.contentResolver.insert(
                CalendarContract.Events.CONTENT_URI,
                values
            )
            
            return uri?.lastPathSegment?.toLongOrNull()
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
    
    /**
     * Gets the default calendar ID.
     * In a production app, you might want to let users choose their calendar.
     */
    private fun getDefaultCalendarId(): Long {
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.IS_PRIMARY
        )
        
        val selection = "${CalendarContract.Calendars.IS_PRIMARY} = 1"
        
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            selection,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idIndex = cursor.getColumnIndex(CalendarContract.Calendars._ID)
                if (idIndex >= 0) {
                    return cursor.getLong(idIndex)
                }
            }
        }
        
        // Fallback: get the first available calendar
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idIndex = cursor.getColumnIndex(CalendarContract.Calendars._ID)
                if (idIndex >= 0) {
                    return cursor.getLong(idIndex)
                }
            }
        }
        
        // Default fallback
        return 1L
    }
    
    /**
     * Checks if calendar permission is granted.
     * Note: Android 14+ requires runtime permission for calendar access.
     */
    fun hasCalendarPermission(): Boolean {
        // For Android 14+, you need to check READ_CALENDAR and WRITE_CALENDAR permissions
        // This is a simplified check - in production, use proper permission checking
        return true
    }
}

