package com.weakglow.linken.data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RemoteAuthRepository(baseUrl: String? = null) {
    private val api: AuthApi? = try {
        val raw = baseUrl ?: ""
        val url = if (raw.isNotBlank() && !raw.endsWith("/")) raw + "/" else raw
        if (url.isBlank()) null else Retrofit.Builder()
            .baseUrl(url)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AuthApi::class.java)
    } catch (_: Exception) { null }

    suspend fun signup(username: String, password: String): Boolean {
        val a = api ?: return false
        return try {
            val res = a.signup(SignupRequest(username, password))
            res.success
        } catch (_: Exception) { false }
    }

    suspend fun login(username: String, password: String): Boolean {
        val a = api ?: return false
        return try {
            val res = a.login(LoginRequest(username, password))
            res.success
        } catch (_: Exception) { false }
    }
}
