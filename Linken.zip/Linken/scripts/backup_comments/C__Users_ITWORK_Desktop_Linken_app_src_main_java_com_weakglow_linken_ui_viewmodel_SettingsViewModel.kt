package com.weakglow.linken.ui.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsViewModel : ViewModel() {
    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _language = MutableStateFlow("en")
    val language: StateFlow<String> = _language.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _username = MutableStateFlow("")
    val username: StateFlow<String> = _username.asStateFlow()

    private val _use24Hour = MutableStateFlow(true)
    val use24Hour: StateFlow<Boolean> = _use24Hour.asStateFlow()

    fun setDarkMode(enabled: Boolean) { _isDarkMode.value = enabled }
    fun setLanguage(lang: String) { _language.value = lang }
    fun setLoggedIn(loggedIn: Boolean) { _isLoggedIn.value = loggedIn }
    fun setUsername(name: String) { _username.value = name }
    fun setUse24Hour(enabled: Boolean) { _use24Hour.value = enabled }
}
