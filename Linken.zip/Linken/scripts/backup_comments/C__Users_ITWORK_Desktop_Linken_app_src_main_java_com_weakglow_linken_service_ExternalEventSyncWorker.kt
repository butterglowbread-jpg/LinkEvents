package com.weakglow.linken.service

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.weakglow.linken.data.AppDatabase
import com.weakglow.linken.data.Event
import com.weakglow.linken.data.EventRepository

class ExternalEventSyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val appContext = applicationContext
        val db = AppDatabase.getDatabase(appContext)
        val repo = EventRepository(db.eventDao())
        val discovery = EventDiscoveryService(appContext)
        val imageGen = ImageGenerationService()

        return try {
            repo.deleteEndedEvents(System.currentTimeMillis())
            val external = discovery.findClosestEvents(System.currentTimeMillis(), daysRange = 30, maxResults = 100)
            for (e in external) {
                val src = e.url
                val existsByUrl = if (!src.isNullOrBlank()) repo.findBySourceUrl(src) else null
                val existsByTitleDate = repo.countByTitleAndDate(e.title, e.dateTime) > 0
                if (existsByUrl == null && !existsByTitleDate) {
                    val normalizedCategory = normalizeCategory(e.category)
                    val imageUrl = e.imageUrl ?: imageGen.generateLocalBannerImage(
                        appContext,
                        title = e.title,
                        dateTime = e.dateTime,
                        location = e.location,
                        category = normalizedCategory
                    )
                    val newEvent = Event(
                        title = e.title,
                        description = e.description,
                        dateTime = e.dateTime,
                        category = normalizedCategory,
                        location = e.location,
                        latitude = e.latitude,
                        longitude = e.longitude,
                        imageUrl = imageUrl,
                        sourceUrl = src,
                        isFavorite = false
                    )
                    val id = repo.insertEvent(newEvent)
                    NotificationWorker.scheduleNotification(appContext, id, newEvent.title, newEvent.dateTime)
                }
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    private fun normalizeCategory(c: String): String {
        val v = c.lowercase()
        return when {
            v.contains("metal") -> "Underground (metal)"
            v.contains("concert") || v.contains("music") || v.contains("festival") -> "Concerts"
            v.contains("club") || v.contains("nightlife") -> "Clubs"
            v.contains("meetup") || v.contains("meeting") -> "Meetings"
            else -> "Gatherings"
        }
    }
}
