package com.weakglow.linken.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerInfoWindowContent
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.CameraPosition
import com.weakglow.linken.data.Event

@Composable
fun EventMapScreen(events: List<Event>) {
    // Simple map screen: show markers for events with coordinates and allow searching by title/location
    val minLat = 53.9
    val maxLat = 56.0
    val minLng = 20.9
    val maxLng = 26.0

    val lithuanianEvents = events.mapNotNull { e ->
        val lat = e.latitude
        val lng = e.longitude
        if (lat != null && lng != null && lat in minLat..maxLat && lng in minLng..maxLng) e else null
    }

    var search by remember { mutableStateOf("") }
    val matched = remember(search, lithuanianEvents) {
        if (search.isBlank()) lithuanianEvents else lithuanianEvents.filter { it.title.contains(search, ignoreCase = true) || (it.location?.contains(search, ignoreCase = true) ?: false) }
    }

    val cameraPositionState = rememberCameraPositionState {
        val first = matched.firstOrNull() ?: lithuanianEvents.firstOrNull()
        position = first?.let { CameraPosition(LatLng(it.latitude ?: 55.1694, it.longitude ?: 23.8813), 12f, 0f, 0f) }
            ?: CameraPosition(LatLng(55.1694, 23.8813), 7f, 0f, 0f)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Simple search field
        androidx.compose.material3.OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            label = { androidx.compose.material3.Text("Search events") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        if (lithuanianEvents.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No events in Lithuania to show on map.")
            }
        } else {
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                properties = MapProperties(mapType = MapType.NORMAL),
                uiSettings = MapUiSettings(zoomControlsEnabled = true)
            ) {
                lithuanianEvents.forEach { event ->
                    val lat = event.latitude ?: return@forEach
                    val lng = event.longitude ?: return@forEach
                    val state = MarkerState(position = LatLng(lat, lng))
                    Marker(state = state, title = event.title, snippet = event.location ?: "")
                }
            }
        }
    }
}
