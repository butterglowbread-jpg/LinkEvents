package com.weakglow.linken.data

import kotlinx.coroutines.flow.Flow

class EventRepository(private val eventDao: EventDao) {
    val allEvents: Flow<List<Event>> = eventDao.getAllEvents()

    fun getEventsByDateRange(startTime: Long, endTime: Long): Flow<List<Event>> {
        return eventDao.getEventsByDateRange(startTime, endTime)
    }

    suspend fun getEventById(id: Long): Event? {
        return eventDao.getEventById(id)
    }

    suspend fun getEventsForDay(startOfDay: Long, endOfDay: Long): List<Event> {
        return eventDao.getEventsForDay(startOfDay, endOfDay)
    }

    suspend fun insertEvent(event: Event): Long {
        return eventDao.insertEvent(event)
    }

    suspend fun updateEvent(event: Event) {
        eventDao.updateEvent(event)
    }

    suspend fun deleteEvent(event: Event) {
        eventDao.deleteEvent(event)
    }

    suspend fun deleteEventById(id: Long) {
        eventDao.deleteEventById(id)
    }

    suspend fun findBySourceUrl(sourceUrl: String): Event? {
        return eventDao.findBySourceUrl(sourceUrl)
    }

    suspend fun countByTitleAndDate(title: String, dateTime: Long): Int {
        return eventDao.countByTitleAndDate(title, dateTime)
    }

    suspend fun deleteEndedEvents(cutoff: Long) {
        eventDao.deleteEndedEvents(cutoff)
    }
}

