package com.weakglow.linken.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface EventDao {
    @Query("SELECT * FROM events ORDER BY dateTime ASC")
    fun getAllEvents(): Flow<List<Event>>

    @Query("SELECT * FROM events WHERE id = :id")
    suspend fun getEventById(id: Long): Event?

    @Query("SELECT * FROM events WHERE dateTime >= :startTime AND dateTime < :endTime ORDER BY dateTime ASC")
    fun getEventsByDateRange(startTime: Long, endTime: Long): Flow<List<Event>>

    @Query("SELECT * FROM events WHERE dateTime >= :startOfDay AND dateTime < :endOfDay ORDER BY dateTime ASC")
    suspend fun getEventsForDay(startOfDay: Long, endOfDay: Long): List<Event>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: Event): Long

    @Update
    suspend fun updateEvent(event: Event)

    @Delete
    suspend fun deleteEvent(event: Event)

    @Query("DELETE FROM events WHERE id = :id")
    suspend fun deleteEventById(id: Long)

    @Query("SELECT * FROM events WHERE sourceUrl = :sourceUrl LIMIT 1")
    suspend fun findBySourceUrl(sourceUrl: String): Event?

    @Query("SELECT COUNT(*) FROM events WHERE title = :title AND dateTime = :dateTime")
    suspend fun countByTitleAndDate(title: String, dateTime: Long): Int

    @Query("DELETE FROM events WHERE dateTime < :cutoff")
    suspend fun deleteEndedEvents(cutoff: Long)
}

