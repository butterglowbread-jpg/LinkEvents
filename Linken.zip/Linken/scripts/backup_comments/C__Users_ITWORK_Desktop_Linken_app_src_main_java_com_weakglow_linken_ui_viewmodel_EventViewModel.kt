package com.weakglow.linken.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.weakglow.linken.data.Event
import com.weakglow.linken.data.EventRepository
import com.weakglow.linken.service.NotificationWorker
import com.weakglow.linken.service.ImageGenerationService
import com.weakglow.linken.service.CalendarService
import com.weakglow.linken.data.ExternalEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class EventUiState(
    val events: List<Event> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class EventViewModel(
    private val repository: EventRepository,
    private val context: Context? = null
) : ViewModel() {
    private val _uiState = MutableStateFlow(EventUiState())
    val uiState: StateFlow<EventUiState> = _uiState.asStateFlow()
    
    private val imageGenerationService = ImageGenerationService()
    private val calendarService: CalendarService? = context?.let { CalendarService(it) }

    val allEvents = repository.allEvents

    private val _preferredCreationDateMs = MutableStateFlow<Long?>(null)
    val preferredCreationDateMs: StateFlow<Long?> = _preferredCreationDateMs.asStateFlow()

    fun setPreferredCreationDate(millis: Long?) {
        _preferredCreationDateMs.value = millis
    }

    fun getEventsByDateRange(startTime: Long, endTime: Long) =
        repository.getEventsByDateRange(startTime, endTime)

    suspend fun getEventById(id: Long): Event? {
        return repository.getEventById(id)
    }

    suspend fun getEventsForDay(startOfDay: Long, endOfDay: Long): List<Event> {
        return repository.getEventsForDay(startOfDay, endOfDay)
    }

    fun insertEvent(event: Event) {
        viewModelScope.launch {
            try {
                // Allow inserting events in the past (removed future-only restriction)
                var eventWithImage = if (event.imageUrl == null && (event.location != null || event.latitude != null)) {
                    val imageUrl = context?.let {
                        imageGenerationService.generateLocalBannerImage(
                            it,
                            title = event.title,
                            dateTime = event.dateTime,
                            location = event.location,
                            category = event.category
                        )
                    }
                    event.copy(imageUrl = imageUrl)
                } else event
                // If this is a locally-created event (no sourceUrl), make it favorited by default
                if (eventWithImage.sourceUrl.isNullOrBlank()) {
                    eventWithImage = eventWithImage.copy(isFavorite = true)
                }
                val duplicate = repository.countByTitleAndDate(eventWithImage.title, eventWithImage.dateTime) > 0
                if (duplicate) {
                    return@launch
                }
                val eventId = repository.insertEvent(eventWithImage)
                context?.let {
                    NotificationWorker.scheduleNotification(
                        it,
                        eventId,
                        eventWithImage.title,
                        eventWithImage.dateTime
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }

    fun updateEvent(event: Event) {
        viewModelScope.launch {
            try {
                // Allow updating events in the past (removed future-only restriction)
                context?.let {
                    NotificationWorker.cancelNotification(it, event.id)
                }

                val eventWithImage = if (event.imageUrl == null && (event.location != null || event.latitude != null)) {
                    val imageUrl = context?.let {
                        imageGenerationService.generateLocalBannerImage(
                            it,
                            title = event.title,
                            dateTime = event.dateTime,
                            location = event.location,
                            category = event.category
                        )
                    }
                    event.copy(imageUrl = imageUrl)
                } else event

                repository.updateEvent(eventWithImage)
                context?.let {
                    NotificationWorker.scheduleNotification(
                        it,
                        eventWithImage.id,
                        eventWithImage.title,
                        eventWithImage.dateTime
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }

    fun deleteEvent(event: Event) {
        viewModelScope.launch {
            try {
                context?.let {
                    NotificationWorker.cancelNotification(it, event.id)
                }
                repository.deleteEvent(event)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }

    fun deleteEventById(id: Long) {
        viewModelScope.launch {
            try {
                context?.let {
                    NotificationWorker.cancelNotification(it, id)
                }
                repository.deleteEventById(id)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }
    
    fun toggleFavorite(event: Event) {
        viewModelScope.launch {
            try {
                val updatedEvent = event.copy(isFavorite = !event.isFavorite)
                repository.updateEvent(updatedEvent)
                if (updatedEvent.isFavorite) {
                    calendarService?.addEventToCalendar(updatedEvent)
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }
    fun addEventToCalendar(event: Event) {
        viewModelScope.launch {
            try {
                calendarService?.addEventToCalendar(event)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }

    fun deletePastEvents() {
        viewModelScope.launch {
            try {
                repository.deleteEndedEvents(System.currentTimeMillis())
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }

    fun upsertFromExternal(ext: ExternalEvent, favorite: Boolean = false) {
        viewModelScope.launch {
            try {
                val src = ext.url ?: ext.id
                val existing = if (!src.isNullOrBlank()) repository.findBySourceUrl(src!!) else null
                val parsed = parseTitleLocation(ext.title)
                val baseEvent = Event(
                    id = existing?.id ?: 0,
                    title = parsed.first,
                    description = ext.description ?: "",
                    dateTime = ext.dateTime,
                    category = ext.category,
                    color = existing?.color ?: 0xFF9C27B0,
                    location = parsed.second ?: ext.location,
                    latitude = ext.latitude,
                    longitude = ext.longitude,
                    imageUrl = ext.imageUrl,
                    sourceUrl = src,
                    isFavorite = favorite || (existing?.isFavorite ?: false)
                )
                if (existing == null) insertEvent(baseEvent) else updateEvent(baseEvent)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }

    private fun parseTitleLocation(title: String): Pair<String, String?> {
        val trimmed = title.trim()
        val regex = Regex("-([A-Za-z0-9À-ÿ'&\\-\\s]+)-([A-Za-z0-9À-ÿ'&\\-\\s]+)-([A-Za-z0-9À-ÿ'&\\-\\s]+)$")
        val m = regex.find(trimmed)
        return if (m != null) {
            val loc = m.groupValues[1].trim()
            val city = m.groupValues[2].trim()
            val country = m.groupValues[3].trim()
            val cleanTitle = trimmed.removeSuffix(m.value).trim().trimEnd('-').trim()
            cleanTitle to listOfNotNull(country, city, loc).joinToString(", ")
        } else trimmed to null
    }

    fun insertStartupEvent() {
        viewModelScope.launch {
            try {
                // Parse datetime: "2025-12-12 10:30"
                val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                val dateTime = dateFormat.parse("2025-12-12 10:30")?.time ?: System.currentTimeMillis()
                
                val event = Event(
                    title = "STARTUOLIŲ DŽIUNGLĖS | Mokomųjų mokinių bendrovių eXpo",
                    description = """Ar imanoma rasti dirbtinio intelekto džiunglėse?🧠

Kokios antrepreneriškos idėjos ar inovatyvūs sprendimai slepiasi tarp palmių?🌴

Daugybė netikėčiausių mokinių verslo idėjų bus pristatytos gruodžio 12 d. "Kalėdinėje eXpo" Litexpo parodų centre Vilniuje!
Nuo su DI kuriamų sprendimų iki skaitmeninių įrankių agro verslui, nuo kiekvienam jaunam žmogui aktualių socialinių problemų iki šalies gynybai svarbių idėjų – Lietuvos Junior Achievement Startuolių džiunglėse rasite visko!🦜

Kalėdinėje „accelerator_x" eXpo parodoje bus išties karšta: net 170 mokomųjų mokinių bendrovių ir daugiau kaip 900 mokinių iš visos Lietuvos.

Komandos jau intensyviai rengiasi pristatyti pasaulį keičiančias idėjas, prototipus, verslo modelius. Kasmet LJA startuolių lygis auga, tobuliau valdomi skaitmeniniai ir DI įrankiai, o idėjos stebina net visko mačiusius verslo lyderius. Lietuvos verslas domisi ir laukia drąsių, aktyvių ir idėjas į veiksmą bei rezultatą transformuojančių komandų.

Į džiungles nerti kviečiame visus: mokytojus, tėvus, mokinius, vilniečius ir miesto svečius, antreprenerystės entuziastus, tiesiog smalsius žmones.

Ateik ir atrask, ką slepia „Startuolių džiunglės"!""",
                    dateTime = dateTime,
                    category = "Gatherings",
                    location = "Lietuvos parodų ir kongresų centras LITEXPO, laisves pr. 5, Vilnius",
                    latitude = 54.6894,  // LITEXPO Vilnius coordinates
                    longitude = 25.2747,
                    imageUrl = "https://www.litexpo.lt/wp-content/uploads/2025/11/startuoliu-dziungles-1920-1080-1-1024x576.jpg",
                    isFavorite = true
                )
                insertEvent(event)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Failed to insert startup event: ${e.message}")
            }
        }
    }

    fun insertIvtkygygEvent() {
        viewModelScope.launch {
            try {
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.YEAR, 2025)
                cal.set(java.util.Calendar.MONTH, java.util.Calendar.DECEMBER)
                cal.set(java.util.Calendar.DAY_OF_MONTH, 13)
                cal.set(java.util.Calendar.HOUR_OF_DAY, 21)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                val dateTime = cal.timeInMillis

                val desc = "Kviečiame į šventinį dviejų dalių, kvadratinio formato, viso kūno suprakaitavimo koncertą nuo galvos skausmo ir dvasinių negalavimų, kuris vyks Gruodžio 13d. 21:00 val. Klube LEMMY\n\nIR VISA TAI KAS YRA GRAŽU YRA GRAŽU\nLegendinė, septynių muzikantų grupė atlieka savo garsiausius kūrinius, skambančius Lietuvos ir Europos nekomercinėse radijo stotyse. Grupė groja koncertuose ir festivaliuose visoje Lietuvoje, leidžia albumus. Kolektyvas atvyksta su dviejų dalių koncertines programa. Kiekviena koncertinė programa – tai pašėlęs žongliravimas tarp sarkazmo, ironijos ir makabriškų motyvų. Trisdešimt aštuonerius metus gyvuojantys IVTKYGYG yra nepagražintas post panko, fanko ir roko sutvėrimas, kuris klausytojams visada yra paruošęs muzikinių siurprizų ir juos įtraukia į scenos performansus. Pasirodymuose kolektyvas groja ir egzotiškais, unikalų skambesį turinčiais, instrumentais, kuriuos mielai pristato publikai, o kai kuriuos leidžia išbandyti.\nBaras 18.00\nKoncetas 21.00\nBilietas 15€ / 12€ (studentai/moksleiviai)"

                val event = Event(
                    title = "IR VISA TAI KAS YRA GRAŽU YRA GRAŽU",
                    description = desc,
                    dateTime = dateTime,
                    category = "Concerts",
                    location = "Girstupio gatvė 1, LT-44328 Kaunas, Lietuva",
                    imageUrl = "https://scontent.fkun1-2.fna.fbcdn.net/v/t39.30808-6/589093128_1358389336075408_7379065959298154189_n.jpg?stp=dst-jpg_s960x960_tt6&_nc_cat=104&_nc_cb=99be929b-f3b7c874&ccb=1-7&_nc_sid=75d36f&_nc_ohc=GZGwIGDlzdoQ7kNvwGwY1v3&_nc_oc=Adl5cid11qXUpNoZ02lwoQC4cZWDd7GZmWewqOi4FBv3cR7-cE0LZa39RMUoNCG4Wak&_nc_zt=23&_nc_ht=scontent.fkun1-2.fna&_nc_gid=TmT2aagRENhnI6oFGp9LLQ&oh=00_Afm9UYl01z2fGhKBwa1z9spxECAA2e5yptA-07-2gRPSXw&oe=6940FCD2",
                    isFavorite = true
                )
                if (repository.countByTitleAndDate(event.title, event.dateTime) == 0) {
                    insertEvent(event)
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Failed to insert event: ${e.message}")
            }
        }
    }

    fun insertKaledzinisServasEvent() {
        viewModelScope.launch {
            try {
                val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                val dateTime = dateFormat.parse("2025-12-20 09:00")?.time
                    ?: System.currentTimeMillis()

                val title = "❄️🎾 ŠVENTINIS PADELIO IR TENISO TURNYRAS „KALĖDZINIS SERVAS“ 🎄🎁"
                val desc = """Gruodžio 20 d. GO Padel komplekse vyks šventinis padelio ir teniso turnyras „Kalėdzinis servas" - pavadinimas, kuris maloniai skamba dzūkiškos tarmės dvasia ir įneša dar daugiau jaukumo artėjančioms šventėms.
\n🏆 TURNYRO INFORMACIJA:
📅 Data: Gruodžio 20 d.
📍Vieta: Kovo 11-osios g. 2, Alytus, Go Padel
🎾 Padelio grupės
🔵 MOTERYS D/C- (liko 1 vieta)
🔵 MOTERYS C (liko 2 vietos)
🔵 BENDRA C- (liko 4 vietos)
🔵 BENDRA C (grupė pilna)
🔵 BENDRA C+/B- (grupė pilna)
🔵 BENDRA B (liko 5 vietos)
🎾 Teniso grupės
⚫️ BENDRA DVEJETAI (LIGHT lygis) - (liko 5 vietos)
⚫️ BENDRA DVEJETAI (MIDDLE lygis) - (atidaryta antra grupė, liko 1 vieta)
⚫️ MOTERŲ DVEJETAI (MIDDLE lygis) - (liko 3 vietos)
📌 REGISTRACIJA:
🔵 Registracija į padelio turnyrą ➡️ https://www.padelution.com/.../sventinis-padelio-turnyras...
⚫ Registracija į teniso turnyrą ➡️ https://forms.gle/J69CML94WGRp6gBG6
📌 Registracija baigiasi gruodžio 18 d. 17:00 val.
📝 Informacija ir registracija: Remigija
📞 +370 620 21620
✉️ remigija@gopadel.lt
💶 STARTINIS MOKESTIS: Padelio startinis mokestis: 45 € / asmeniui; Teniso startinis mokestis: 50 € / asmeniui
"""
                val event = Event(
                    title = title,
                    description = desc,
                    dateTime = dateTime,
                    category = "Sports",
                    location = "Kovo 11-osios g. 2, LT-63199 Alytus, Lithuania",
                    imageUrl = "https://scontent.fkun1-1.fna.fbcdn.net/v/t39.30808-6/588343433_122214809324262082_7344715905720589033_n.jpg?stp=dst-jpg_s960x960_tt6&_nc_cat=103&_nc_cb=99be929b-f3b7c874&ccb=1-7&_nc_sid=75d36f&_nc_ohc=lTRYDGSz2lAQ7kNvwGxH3uk&_nc_oc=Admftrh5V1u_hbWK2OGS_HPVTm6-nzBJJXPUkW8AqTkYf46NNMN9Mxw8J_R1sEJ4R_k&_nc_zt=23&_nc_ht=scontent.fkun1-1.fna&_nc_gid=o7red9J8K96-R5bQAM29Yw&oh=00_Afm0GhK7ZWoJLHrTfNu4UPcDSge8W7C4ay0Ii7USS3XC_A&oe=694125A4",
                    isFavorite = true
                )
                if (repository.countByTitleAndDate(event.title, event.dateTime) == 0) {
                    insertEvent(event)
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Failed to insert KALĖDZINIS SERVAS event: ${e.message}")
            }
        }
    }

    fun insertKaleduSenelisEvents() {
        viewModelScope.launch {
            try {
                val dates = listOf(
                    "2025-12-07 12:00",
                    "2025-12-13 12:00",
                    "2025-12-14 12:00",
                    "2025-12-20 12:00",
                    "2025-12-21 12:00",
                    "2025-12-25 12:00"
                )
                val df = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                val title = "KALĖDŲ SENELIS KVIEČIA PASISVEČIUOTI | Kalėdų senelio rezidencija Marijampolėje"
                val description = "Kalėdų Senelis kviečia pasisvečiuoti! 🎅🏻✨\n❄ Kokios šventės be magiškos pasakos?\n⛄ J. Basanavičiaus aikštėje įsikūrusi Kalėdų Senelio rezidencija kviečia užeiti visus, kurie yra išsiilgę šventinės šilumos, jaukumo ir mažų žiemos stebuklų.\n🧣 Susitikti su Kalėdų Seneliu galėsite šiais laikas."
                for (d in dates) {
                    val dt = df.parse(d)?.time ?: continue
                    val ev = Event(
                        title = title,
                        description = description,
                        dateTime = dt,
                        category = "Gatherings",
                        location = "J. Basanavičiaus aikštė, Marijampolė, Lietuva",
                        imageUrl = "https://scontent.fkun1-2.fna.fbcdn.net/v/t39.30808-6/584431253_1302716778556960_607071932738072109_n.jpg?stp=dst-jpg_s960x960_tt6&_nc_cat=105&_nc_cb=99be929b-f3b7c874&ccb=1-7&_nc_sid=75d36f&_nc_ohc=8C0EK024AVsQ7kNvwEB7Icn&_nc_oc=AdmR_D8gf3Se--FpIlQzRTdONnzpfWMztQEx2bpqQ2f5_7uWjoiK1JSAOi2aqrGnNM0&_nc_zt=23&_nc_ht=scontent.fkun1-2.fna&_nc_gid=AWPqCVDpDuG23clgmT3eJQ&oh=00_AfnVNCv_Ogg1lsT48gcJC2yFpLfG5ITg9VVxz2T_wk2RDg&oe=6941280C",
                        isFavorite = true
                    )
                    if (repository.countByTitleAndDate(ev.title, ev.dateTime) == 0) {
                        insertEvent(ev)
                    }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Failed to insert Kaledu Senelis events: ${e.message}")
            }
        }
    }
}

class EventViewModelFactory(
    private val repository: EventRepository,
    private val context: Context? = null
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EventViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EventViewModel(repository, context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

