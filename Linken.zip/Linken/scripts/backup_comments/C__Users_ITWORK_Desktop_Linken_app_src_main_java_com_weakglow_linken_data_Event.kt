package com.weakglow.linken.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "events")
data class Event(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val dateTime: Long, // Unix timestamp
    val category: String = "General",
    val color: Long = 0xFF9C27B0, // Default purple accent color
    val location: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val imageUrl: String? = null,
    val sourceUrl: String? = null,
    val isFavorite: Boolean = false
)

