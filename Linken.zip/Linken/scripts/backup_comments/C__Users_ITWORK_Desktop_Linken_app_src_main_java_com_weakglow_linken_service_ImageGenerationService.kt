package com.weakglow.linken.service

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import java.io.File
import java.io.FileOutputStream

class ImageGenerationService {
    private val unsplashSourceBaseUrl = "https://source.unsplash.com/800x600/?"

    suspend fun generateImageUrl(
        title: String? = null,
        location: String? = null,
        latitude: Double? = null,
        longitude: Double? = null,
        category: String = "General"
    ): String? = withContext(Dispatchers.IO) {
        try {
            val loc = location?.takeIf { it.isNotBlank() }
            if (loc != null) {
                val apiKey = com.weakglow.linken.BuildConfig.GOOGLE_SEARCH_API_KEY
                val cx = com.weakglow.linken.BuildConfig.GOOGLE_SEARCH_CX
                if (!apiKey.isNullOrBlank() && !cx.isNullOrBlank()) {
                    val q = URLEncoder.encode(loc, "UTF-8")
                    val url = "https://www.googleapis.com/customsearch/v1?key=$apiKey&cx=$cx&searchType=image&num=1&q=$q"
                    try {
                        val conn = URL(url).openConnection() as HttpURLConnection
                        conn.requestMethod = "GET"
                        conn.connectTimeout = 5000
                        conn.readTimeout = 7000
                        val code = conn.responseCode
                        if (code == 200) {
                            val body = conn.inputStream.bufferedReader().use { it.readText() }
                            val json = JSONObject(body)
                            val items = json.optJSONArray("items")
                            val first = items?.optJSONObject(0)
                            val link = first?.optString("link")
                            if (!link.isNullOrBlank()) return@withContext link
                        }
                    } catch (_: Exception) {}
                }
            }

            val searchQuery = when {
                loc != null -> URLEncoder.encode(loc, "UTF-8")
                latitude != null && longitude != null -> "location,$latitude,$longitude"
                title != null && title.isNotBlank() -> URLEncoder.encode(title, "UTF-8")
                else -> URLEncoder.encode(category, "UTF-8")
            }
            "$unsplashSourceBaseUrl$searchQuery"
        } catch (_: Exception) {
            "$unsplashSourceBaseUrl${URLEncoder.encode(category, "UTF-8")}" 
        }
    }

    suspend fun generateLocalBannerImage(
        context: Context,
        title: String?,
        dateTime: Long?,
        location: String?,
        category: String
    ): String? = withContext(Dispatchers.IO) {
        try {
            val w = 1200
            val h = 630
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val bg = Paint()
            bg.color = categoryColor(category)
            canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
            titlePaint.color = Color.WHITE
            titlePaint.textSize = 64f
            titlePaint.typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
            val infoPaint = Paint(Paint.ANTI_ALIAS_FLAG)
            infoPaint.color = Color.WHITE
            infoPaint.textSize = 36f
            val margin = 48f
            var y = margin + 64f
            val maxTextWidth = (w - (margin * 2f)).toInt()
            wrapAndDraw(canvas, title ?: "", titlePaint, margin, y, maxTextWidth).also { y += it + 24f }
            val df = java.text.SimpleDateFormat("EEEE, MMM d yyyy • HH:mm", java.util.Locale.getDefault())
            val dateStr = dateTime?.let { df.format(java.util.Date(it)) } ?: ""
            wrapAndDraw(canvas, listOfNotNull(location).joinToString(" "), infoPaint, margin, y, maxTextWidth).also { y += it + 16f }
            if (dateStr.isNotBlank()) wrapAndDraw(canvas, dateStr, infoPaint, margin, y, maxTextWidth)
            val dir = File(context.cacheDir, "banners")
            if (!dir.exists()) dir.mkdirs()
            val name = "event_${System.currentTimeMillis()}_${(title ?: "").hashCode()}.jpg"
            val file = File(dir, name)
            FileOutputStream(file).use { fos -> bmp.compress(Bitmap.CompressFormat.JPEG, 85, fos) }
            bmp.recycle()
            "file://${file.absolutePath}"
        } catch (_: Exception) {
            null
        }
    }

    private fun wrapAndDraw(canvas: Canvas, text: String, paint: Paint, x: Float, yStart: Float, maxWidth: Int): Float {
        if (text.isBlank()) return 0f
        val words = text.split(' ')
        var line = StringBuilder()
        var y = yStart
        var linesHeight = 0f
        val lineHeight = paint.textSize + 8f
        for (w in words) {
            val candidate = if (line.isEmpty()) w else line.toString() + " " + w
            if (paint.measureText(candidate) > maxWidth) {
                canvas.drawText(line.toString(), x, y, paint)
                y += lineHeight
                linesHeight += lineHeight
                line = StringBuilder(w)
            } else {
                line = StringBuilder(candidate)
            }
        }
        if (line.isNotEmpty()) {
            canvas.drawText(line.toString(), x, y, paint)
            linesHeight += lineHeight
        }
        return linesHeight
    }

    private fun categoryColor(category: String): Int {
        val c = category.lowercase()
        return when {
            c.contains("metal") -> Color.parseColor("#4A148C")
            c.contains("concert") || c.contains("music") || c.contains("festival") -> Color.parseColor("#1E88E5")
            c.contains("club") || c.contains("nightlife") -> Color.parseColor("#D81B60")
            c.contains("meetup") || c.contains("meeting") -> Color.parseColor("#43A047")
            else -> Color.parseColor("#546E7A")
        }
    }
}

