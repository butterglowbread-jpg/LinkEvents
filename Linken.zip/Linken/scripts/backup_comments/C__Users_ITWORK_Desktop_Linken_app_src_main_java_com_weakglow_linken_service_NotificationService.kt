package com.weakglow.linken.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.weakglow.linken.MainActivity
import java.util.concurrent.TimeUnit

class NotificationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val eventTitle = inputData.getString(KEY_EVENT_TITLE) ?: return Result.failure()
        val eventId = inputData.getLong(KEY_EVENT_ID, -1L)

        showNotification(applicationContext, eventTitle, eventId)

        return Result.success()
    }

    private fun showNotification(context: Context, title: String, eventId: Long) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Event Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for upcoming events"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Event Reminder")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(eventId.toInt(), notification)
    }

    companion object {
        const val KEY_EVENT_TITLE = "event_title"
        const val KEY_EVENT_ID = "event_id"
        const val CHANNEL_ID = "event_reminders"

        fun scheduleNotification(
            context: Context,
            eventId: Long,
            eventTitle: String,
            eventTimeMillis: Long
        ) {
            val currentTime = System.currentTimeMillis()
            val delay = eventTimeMillis - currentTime - TimeUnit.MINUTES.toMillis(15) // 15 minutes before

            if (delay > 0) {
                val inputData = Data.Builder()
                    .putString(KEY_EVENT_TITLE, eventTitle)
                    .putLong(KEY_EVENT_ID, eventId)
                    .build()

                val notificationRequest = OneTimeWorkRequestBuilder<NotificationWorker>()
                    .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                    .setInputData(inputData)
                    .addTag("event_$eventId")
                    .build()

                WorkManager.getInstance(context).enqueue(notificationRequest)
            }
        }

        fun cancelNotification(context: Context, eventId: Long) {
            WorkManager.getInstance(context).cancelAllWorkByTag("event_$eventId")
        }
    }
}

