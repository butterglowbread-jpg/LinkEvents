package com.weakglow.linken.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.weakglow.linken.data.Event
import com.weakglow.linken.ui.navigation.Screen
import com.weakglow.linken.ui.viewmodel.EventViewModel

import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CalendarScreen(
    navController: NavController,
    viewModel: EventViewModel
) {
    val events by viewModel.allEvents.collectAsState(initial = emptyList())
    var selectedDate by remember { mutableStateOf(Calendar.getInstance()) }
    
    val calendar = remember(selectedDate) {
        Calendar.getInstance().apply {
            time = selectedDate.time
            set(Calendar.DAY_OF_MONTH, 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Month/Year Header with Navigation
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    calendar.add(Calendar.MONTH, -1)
                    selectedDate = calendar.clone() as Calendar
                }
            ) {
                Text("◀", style = MaterialTheme.typography.titleLarge)
            }

            Text(
                text = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(calendar.time),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            IconButton(
                onClick = {
                    calendar.add(Calendar.MONTH, 1)
                    selectedDate = calendar.clone() as Calendar
                }
            ) {
                Text("▶", style = MaterialTheme.typography.titleLarge)
            }
        }

        // Calendar Grid
        CalendarGrid(
            calendar = calendar,
            events = events,
            onDateClick = { millis ->
                selectedDate = Calendar.getInstance().apply { timeInMillis = millis }
                viewModel.setPreferredCreationDate(millis)
            }
        )

        // Events for selected month
        val monthEvents = events.filter { event ->
            val eventCalendar = Calendar.getInstance().apply {
                timeInMillis = event.dateTime
            }
            eventCalendar.get(Calendar.YEAR) == calendar.get(Calendar.YEAR) &&
            eventCalendar.get(Calendar.MONTH) == calendar.get(Calendar.MONTH)
        }

        if (monthEvents.isNotEmpty()) {
            Text(
                text = "Events this month",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(monthEvents, key = { it.id }) { event ->
                    EventListItem(
                        event = event,
                        onClick = {
                            navController.navigate(Screen.Detail.createRoute(event.id))
                        }
                    )
                }
            }
        }

        // Events for selected day
        val dayEvents = events.filter { event ->
            val eventCalendar = Calendar.getInstance().apply {
                timeInMillis = event.dateTime
            }
            eventCalendar.get(Calendar.YEAR) == selectedDate.get(Calendar.YEAR) &&
            eventCalendar.get(Calendar.MONTH) == selectedDate.get(Calendar.MONTH) &&
            eventCalendar.get(Calendar.DAY_OF_MONTH) == selectedDate.get(Calendar.DAY_OF_MONTH)
        }

        Text(
            text = SimpleDateFormat("EEEE, MMM d, yyyy", Locale.getDefault()).format(selectedDate.time),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp)
        )

        if (dayEvents.isNotEmpty()) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(dayEvents, key = { it.id }) { event ->
                    EventListItem(
                        event = event,
                        onClick = {
                            navController.navigate(Screen.Detail.createRoute(event.id))
                        }
                    )
                }
            }
        } else {
            Text("No events for this day.", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun CalendarGrid(
    calendar: Calendar,
    events: List<Event>,
    onDateClick: (Long) -> Unit
) {
    val firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
    val daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH)
    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH)

    // Get events for this month
    val monthEvents = events.filter { event ->
        val eventCalendar = Calendar.getInstance().apply {
            timeInMillis = event.dateTime
        }
        eventCalendar.get(Calendar.YEAR) == year &&
        eventCalendar.get(Calendar.MONTH) == month
    }.groupBy { event ->
        val eventCalendar = Calendar.getInstance().apply {
            timeInMillis = event.dateTime
        }
        eventCalendar.get(Calendar.DAY_OF_MONTH)
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Day headers
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat").forEach { day ->
                Text(
                    text = day,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Calendar days
        var dayCounter = 1
        repeat(6) { week ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                repeat(7) { dayOfWeek ->
                    if (week == 0 && dayOfWeek < firstDayOfWeek - 1) {
                        // Empty cell before first day of month
                        Spacer(modifier = Modifier.weight(1f))
                    } else if (dayCounter <= daysInMonth) {
                        val day = dayCounter
                        val hasEvents = monthEvents.containsKey(day)
                        val today = Calendar.getInstance().let {
                            it.get(Calendar.YEAR) == year &&
                            it.get(Calendar.MONTH) == month &&
                            it.get(Calendar.DAY_OF_MONTH) == day
                        }

                        val calendarDay = Calendar.getInstance().apply {
                            set(year, month, day)
                        }

                        // Determine color based on events for the day
                        val dayColor = monthEvents[day]?.let { eventsForDay ->
                            if (eventsForDay.isNotEmpty()) {
                                // Use the color of the first event, or blend if multiple
                                val colors = eventsForDay.map { it.color }
                                val avgColor = colors.map { Color(it) }.reduce { acc, c ->
                                    Color(
                                        red = ((acc.red + c.red) / 2),
                                        green = ((acc.green + c.green) / 2),
                                        blue = ((acc.blue + c.blue) / 2),
                                        alpha = 1f
                                    )
                                }
                                avgColor
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            }
                        } ?: MaterialTheme.colorScheme.surfaceVariant

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp)
                                .clip(CircleShape)
                                .background(dayColor)
                                .clickable {
                                    onDateClick(calendarDay.timeInMillis)
                                },
                            contentAlignment = Alignment.TopCenter
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Top
                            ) {
                                Text(
                                    text = day.toString(),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (hasEvents) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                val count = monthEvents[day]?.size ?: 0
                                if (count > 0) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        shape = CircleShape
                                    ) {
                                        Text(
                                            text = count.toString(),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                        dayCounter++
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
fun EventListItem(
    event: Event,
    onClick: () -> Unit
) {
    val dateFormat = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
    val dateString = dateFormat.format(Date(event.dateTime))

    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .clip(MaterialTheme.shapes.small)
                    .background(Color(event.color))
            )

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = dateString,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

