package com.weakglow.linken

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import androidx.compose.runtime.collectAsState
import com.weakglow.linken.data.AppDatabase
import com.weakglow.linken.data.EventRepository
import com.weakglow.linken.data.Event
import com.weakglow.linken.ui.navigation.NavGraph
import com.weakglow.linken.ui.navigation.Screen
import com.weakglow.linken.ui.theme.LinkenTheme
import com.weakglow.linken.ui.viewmodel.EventDiscoveryViewModel
import com.weakglow.linken.ui.viewmodel.EventViewModel
import com.weakglow.linken.ui.viewmodel.EventViewModelFactory
import com.weakglow.linken.service.ImageGenerationService
import com.weakglow.linken.ui.viewmodel.SettingsViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val repository = EventRepository(database.eventDao())

        setContent {
            val settings: SettingsViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
            val context = androidx.compose.ui.platform.LocalContext.current
            val darkMode = settings.isDarkMode.collectAsState().value
            val languageState = settings.language.collectAsState()
                androidx.compose.runtime.LaunchedEffect(Unit) {
                    val savedDark = com.weakglow.linken.ui.viewmodel.SettingsStorage.loadDarkMode(context)
                    val savedLang = com.weakglow.linken.ui.viewmodel.SettingsStorage.loadLanguage(context)
                    val savedLogged = com.weakglow.linken.ui.viewmodel.SettingsStorage.loadLoggedIn(context)
                    val savedUser = com.weakglow.linken.ui.viewmodel.SettingsStorage.loadUsername(context)
                    val use24h = com.weakglow.linken.ui.viewmodel.SettingsStorage.loadUse24Hour(context)
                    settings.setDarkMode(savedDark)
                    settings.setLanguage(savedLang)
                    settings.setLoggedIn(savedLogged)
                    settings.setUsername(savedUser)
                    settings.setUse24Hour(use24h)
                }
            LinkenTheme(darkTheme = darkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    val viewModel: EventViewModel = viewModel(
                        factory = EventViewModelFactory(repository, applicationContext)
                    )
                    val discoveryViewModel = EventDiscoveryViewModel()

                    NavGraph(
                        navController = navController,
                        viewModel = viewModel,
                        discoveryViewModel = discoveryViewModel,
                        startDestination = Screen.Main.route,
                        settingsViewModel = settings
                    )
                }
            }
        }

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val syncRequest = PeriodicWorkRequestBuilder<com.weakglow.linken.service.ExternalEventSyncWorker>(15, java.util.concurrent.TimeUnit.MINUTES)
            .setConstraints(constraints)
            .addTag("external_event_sync")
            .build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "external_event_sync",
            androidx.work.ExistingPeriodicWorkPolicy.UPDATE,
            syncRequest
        )

        lifecycleScope.launch {
            val imageGen = ImageGenerationService()
            val now = System.currentTimeMillis()
            val seeds = listOf(
                Triple("Metal Night", "Vilnius, Legendos Klubas", "Underground (metal)"),
                Triple("Jazz Evening", "Kaunas, Old Town", "Concerts")
            )
            for ((title, location, category) in seeds) {
                val dateMs = now + 7L * 24 * 60 * 60 * 1000
                val exists = repository.countByTitleAndDate(title, dateMs)
                if (exists == 0) {
                    val imageUrl = imageGen.generateLocalBannerImage(
                        applicationContext,
                        title = title,
                        dateTime = dateMs,
                        location = location,
                        category = category
                    )
                    val ev = Event(
                        title = title,
                        description = "",
                        dateTime = dateMs,
                        category = category,
                        location = location,
                        imageUrl = imageUrl
                    )
                    repository.insertEvent(ev)
                }
            }

            val customTitle = "Skolos nuskendusios pelkėje traukimas"
            val customDescription = "renkam lėšas su:MINISTRY OF ECHOLOGY [vno] reggae\nDR. GREEN [vno] ska-punk\nFRIZZ [alt] indie"
            val customCategory = "Concerts"
            val customLocation = "SODAS 2123"
            val customImageUrl = "https://scontent.fkun1-1.fna.fbcdn.net/v/t39.30808-6/559367249_1285914473335711_333545524183500856_n.jpg?stp=dst-jpg_s960x960_tt6&_nc_cat=110&_nc_cb=99be929b-f3b7c874&ccb=1-7&_nc_sid=75d36f&_nc_ohc=fSNPp3U8bJcQ7kNvwEJNi4P&_nc_oc=AdmeoMvKQxTm4SKoauglui3lI0f2OzMAvNP3ZQ-p5ySIOUk7JJCntXPYilbYtQVPMDY&_nc_zt=23&_nc_ht=scontent.fkun1-1.fna&_nc_gid=pn-M1WWmO8P-zSVYUf5qZQ&oh=00_AfmqL4f_Z-UISogKQiL4lfdvtTcHdHb8DTOtz_GZKUqZ1A&oe=693C8DE4"
            val customDateMs = try {
                val f = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                f.timeZone = java.util.TimeZone.getDefault()
                f.parse("2025-12-12 19:00")?.time ?: now
            } catch (_: Exception) { now }
            val existsCustom = repository.countByTitleAndDate(customTitle, customDateMs)
            if (existsCustom == 0) {
                val ev = Event(
                    title = customTitle,
                    description = customDescription,
                    dateTime = customDateMs,
                    category = customCategory,
                    location = customLocation,
                    imageUrl = customImageUrl
                )
                repository.insertEvent(ev)
            }
        }
    }
}
