Param(
    [string]$Root = "app/src/main/java"
)

function Remove-CommentsFromFile {
    param([string]$path)
    $text = Get-Content -Raw -Encoding UTF8 $path
    $len = $text.Length
    $sb = New-Object System.Text.StringBuilder
    $i = 0
    $inLine = $false
    $inBlock = $false
    $inDouble = $false
    $inSingle = $false
    $inTriple = $false
    $escape = $false

    while ($i -lt $len) {
        $ch = $text[$i]
        $next = $null
        if ($i + 1 -lt $len) { $next = $text[$i + 1] }
        if ($inBlock) {
            if ($ch -eq '*' -and $next -eq '/') { $inBlock = $false; $i += 2; continue }
            $i++ ; continue
        }
        if ($inLine) {
            if ($ch -eq "`n") { $inLine = $false; $sb.Append($ch) | Out-Null; $i++ ; continue }
            $i++ ; continue
        }
        if ($inTriple) {
            if ($ch -eq '"' -and $i + 2 -lt $len -and $text[$i+1] -eq '"' -and $text[$i+2] -eq '"') { $inTriple = $false; $sb.Append('"""') | Out-Null; $i += 3; continue }
            $sb.Append($ch) | Out-Null; $i++; continue
        }
        if ($inDouble) {
            $sb.Append($ch) | Out-Null
            if ($ch -eq '\\' -and -not $escape) { $escape = $true; $i++; continue }
            if ($ch -eq '"' -and -not $escape) { $inDouble = $false }
            if ($escape) { $escape = $false }
            $i++ ; continue
        }
        if ($inSingle) {
            $sb.Append($ch) | Out-Null
            if ($ch -eq '\\' -and -not $escape) { $escape = $true; $i++; continue }
            if ($ch -eq "'" -and -not $escape) { $inSingle = $false }
            if ($escape) { $escape = $false }
            $i++ ; continue
        }

        # Not currently inside any string/comment
        if ($ch -eq '/' -and $next -eq '*') { $inBlock = $true; $i += 2 ; continue }
        if ($ch -eq '/' -and $next -eq '/') { $inLine = $true; $i += 2 ; continue }
        if ($ch -eq '"') {
            # Check for triple quotes
            if ($i + 2 -lt $len -and $text[$i+1] -eq '"' -and $text[$i+2] -eq '"') { $inTriple = $true; $sb.Append('"""') | Out-Null; $i += 3; continue }
            $inDouble = $true; $sb.Append($ch) | Out-Null; $i++; continue
        }
        if ($ch -eq "'") { $inSingle = $true; $sb.Append($ch) | Out-Null; $i++; continue }

        $sb.Append($ch) | Out-Null
        $i++
    }

    $result = $sb.ToString()
    Set-Content -Encoding UTF8 -Path $path -Value $result
}

$backupRoot = Join-Path (Get-Location) "scripts\backup_comments"
if (-not (Test-Path $backupRoot)) { New-Item -ItemType Directory -Path $backupRoot | Out-Null }

$files = Get-ChildItem -Path $Root -Include *.kt, *.java -Recurse
foreach ($f in $files) {
    $dest = Join-Path $backupRoot ($f.FullName -replace '[:\\]', '_')
    Copy-Item -Force -Path $f.FullName -Destination $dest
    Remove-CommentsFromFile -path $f.FullName
    Write-Host "Stripped comments from: $($f.FullName)"
}

Write-Host "Completed stripping comments for $($files.Count) files. Backups at $backupRoot"
