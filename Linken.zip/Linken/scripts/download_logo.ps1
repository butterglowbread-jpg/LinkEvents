param(
    [Parameter(Mandatory=$true)]
    [string]$url
)

# Save path relative to the workspace root
$dst = "app/src/main/res/drawable/logo.png"
$fullDst = Join-Path (Resolve-Path .).Path $dst
$dir = Split-Path $fullDst -Parent
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

Write-Host "Downloading logo from: $url"
try {
    Invoke-WebRequest -Uri $url -OutFile $fullDst -UseBasicParsing
    Write-Host "Saved to: $fullDst"
} catch {
    Write-Error "Failed to download or save the file: $_"
    exit 1
}

# Inform user
Write-Host "You can now rebuild the app; if the image is too large, consider scaling it to an appropriate density."
